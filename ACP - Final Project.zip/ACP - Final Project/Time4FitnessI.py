import mysql.connector
import re
import tkinter as tk
from tkinter import ttk
import customtkinter as ctk
from customtkinter import CTkFont
from tkinter import messagebox
import datetime
#-----------------------------DATABASE FUNCTION-----------------------------#
def databasejoin(): #This is to enter the database named FitnessDB
    return mysql.connector.connect(
        host="localhost",
        user="root",
        password="",
        database="FitnessDB"
    )
#-----------------------------USER DASHBOARD--------------------------------#
def UserDashboard(user_id): #This function is to display the following functions in the bottom of this Function
    global dashboard
    dashboard = ctk.CTkToplevel(app)
    dashboard.geometry("600x500")
    dashboard.resizable(False,False)
    dashboard.title("User Dashboard")

    screen_width = dashboard.winfo_screenwidth()    #This line is to center the window
    screen_height = dashboard.winfo_screenheight()
    x = (screen_width // 2) - (600 // 2)
    y = (screen_height // 2) - (500 // 2)
    dashboard.geometry(f"600x500+{x}+{y}")

    ctk.CTkLabel(dashboard, text="Welcome to Your Dashboard", font=("Helvetica", 20)).pack(pady=20)

    user_info_button = ctk.CTkButton(dashboard, text="User Information", width=200, command=lambda: UserInfoWindow(user_id))
    user_info_button.pack(pady=10)

    exercise_log_button = ctk.CTkButton(dashboard, text="Exercise Log", width=200, command=lambda: ExerciseLogWindow(user_id))
    exercise_log_button.pack(pady=10)

    attendance_button = ctk.CTkButton(dashboard, text="Attendance", width=200, command=lambda: attendance_window(user_id))
    attendance_button.pack(pady=10)

    payment_history_button = ctk.CTkButton(dashboard, text="Payment History", width=200, command=lambda: PaymentHistoryWindow(user_id))
    payment_history_button.pack(pady=10)

    Logout_button = ctk.CTkButton(dashboard, text="Log-out", width=200, command=backtoLogin)
    Logout_button.pack(pady=10)

def Loginclearinput():  #this is to clear all the login informations that the user or admin will input in the username and password
    usern.delete(0, tk.END)
    passw.delete(0, tk.END)

def backtoLogin(): #This function is designed for the user to logged them out of their dashboard
    global dashboard
    if dashboard:
        dashboard.destroy()
        dashboard = None
        messagebox.showinfo("Logout", "You have been logged out.") 
    Loginclearinput()
    app.deiconify()

def attendance_window(user_id): #This function for attendance window
    global dashboard
    dashboard.withdraw()

    attendance = ctk.CTkToplevel(app)
    attendance.geometry("500x400")
    attendance.resizable(False, False)
    attendance.title("Attendance")

    ctk.CTkLabel(attendance, text="Attendance Check-In", font=("Helvetica", 18)).pack(pady=20)

    screen_width = app.winfo_screenwidth()  #This is to center the window
    screen_height = app.winfo_screenheight()
    x = (screen_width // 2) - (500 // 2)
    y = (screen_height // 2) - (500 // 2)
    attendance.geometry(f"500x500+{x}+{y}") 

    try:
        conn = databasejoin()
        cursor = conn.cursor()

        today = datetime.date.today()

        # Add this check before executing the attendance or exercise log code
        cursor.execute("SELECT Status FROM Users WHERE User_ID = %s", (user_id,))
        account_status = cursor.fetchone()

        if account_status and account_status[0] in ['Expired', 'Suspended']:
            messagebox.showerror("Account Inactive", "Your account is either expired or suspended. You cannot log attendance or exercises.")
            attendance.destroy()
            dashboard.deiconify()
            return

        cursor.execute("""
            SELECT Attendance_ID FROM Attendance WHERE User_ID = %s AND Attendance_Date = %s """, (user_id, today))
        already_checked_in = cursor.fetchone()

        if already_checked_in:
            ctk.CTkLabel(attendance, text="You have already checked in today.", font=("Arial", 12), fg_color="green").pack(pady=10)
        else:
            def check_in():
                try:
                    conn = databasejoin()
                    cursor = conn.cursor()

                    check_in_time = datetime.datetime.now().time()
                    cursor.execute(""" INSERT INTO Attendance (User_ID, Attendance_Date, Check_In_Time, Status) VALUES (%s, %s, %s, 'Present') """, (user_id, today, check_in_time))
                    conn.commit()

                    cursor.close()
                    conn.close()

                    messagebox.showinfo("Success", "Check-in successful!")
                    attendance.destroy()
                    dashboard.deiconify()
                except Exception as e:
                    messagebox.showerror("Database Error", f"Error during check-in: {e}")

            ctk.CTkButton(attendance, text="Check In", command=check_in).pack(pady=10)

        ctk.CTkLabel(attendance, text="Your Attendance Records:", font=("Arial", 14)).pack(pady=20) #This will dispklay attendance record in a treeview

        columns = ("attendance_date", "status")
        attendance_tree = ttk.Treeview(attendance, columns=columns, show="headings", height=10)
        attendance_tree.heading("attendance_date", text="Attendance Date")
        attendance_tree.heading("status", text="Status")

        attendance_tree.column("attendance_date", width=150, anchor="center")
        attendance_tree.column("status", width=100, anchor="center")
        attendance_tree.pack(pady=10, fill="both", expand=True)

        scrollbar = ttk.Scrollbar(attendance, orient="vertical", command=attendance_tree.yview)
        attendance_tree.config(yscrollcommand=scrollbar.set)
        scrollbar.pack(side="right", fill="y")

        cursor.execute(""" SELECT Attendance_Date, Status FROM Attendance WHERE User_ID = %s """, (user_id,))
        attendance_data = cursor.fetchall()

        cursor.close()
        conn.close()

        if not attendance_data:
            ctk.CTkLabel(attendance, text="No attendance records found.", font=("Arial", 12)).pack(pady=10)
        else:
            for date, status in attendance_data:
                attendance_tree.insert("", "end", values=(date, status))

    except Exception as e:
        messagebox.showerror("Database Error", f"Error fetching attendance data: {e}")
        return
    
    def attendanceback():
        attendance.destroy()
        dashboard.deiconify()

    ctk.CTkButton(attendance, text="Go Back", command=attendanceback).pack(pady=20)

def PaymentHistoryWindow(user_id): #This function is prompts the user to pay.. if not yet approved by the admin (pending)
    global dashboard
    dashboard.withdraw()

    payment_history = ctk.CTkToplevel(app)
    payment_history.geometry("600x500")
    payment_history.resizable(False, False)
    payment_history.title("Payment Section")

    screen_width = app.winfo_screenwidth()
    screen_height = app.winfo_screenheight()
    x = (screen_width // 2) - (600 // 2)
    y = (screen_height // 2) - (500 // 2)
    payment_history.geometry(f"600x500+{x}+{y}")

    ctk.CTkLabel(payment_history, text="Payment Details", font=("Helvetica", 18)).pack(pady=20)

    try:
        conn = databasejoin()
        cursor = conn.cursor()

        cursor.execute(""" SELECT m.Membership_ID, m.Membership_Type, m.Membership_Cost, um.Membership_Start_Date, um.Membership_Duration
            FROM User_Memberships um JOIN Memberships m ON um.Membership_ID = m.Membership_ID WHERE um.User_ID = %s """, (user_id,))
        membership_info = cursor.fetchone()
        conn.close()
    except Exception as e:
        messagebox.showerror("Database Error", f"Error fetching membership information: {e}")
        return

    if not membership_info:
        ctk.CTkLabel(payment_history, text="No membership information found.", font=("Arial", 12)).pack(pady=10)
        return

    membership_id, membership_type, membership_cost, start_date, duration = membership_info

    expiry_date = start_date + datetime.timedelta(days=duration)
    today = datetime.date.today()

    ctk.CTkLabel(payment_history, text=f"Membership Type: {membership_type}", font=("Arial", 14)).pack(pady=5)
    ctk.CTkLabel(payment_history, text=f"Membership Cost: ₱{membership_cost:,.2f}", font=("Arial", 14)).pack(pady=5)
    ctk.CTkLabel(payment_history, text=f"Membership Start Date: {start_date}", font=("Arial", 14)).pack(pady=5)
    ctk.CTkLabel(payment_history, text=f"Membership Expiry Date: {expiry_date}", font=("Arial", 14)).pack(pady=5)

    # Check if the user has already made a payment for this membership
    try:
        conn = databasejoin()
        cursor = conn.cursor()

        cursor.execute("""
            SELECT Payment_ID, Status 
            FROM Payments 
            WHERE User_ID = %s AND Membership_ID = %s
        """, (user_id, membership_id))
        existing_payment = cursor.fetchone()
        conn.close()
    except Exception as e:
        messagebox.showerror("Database Error", f"Error checking payment history: {e}")
        return

    if existing_payment:
        payment_status = existing_payment[1]
        ctk.CTkLabel(payment_history, text=f"Payment Status: {payment_status}", font=("Arial", 14)).pack(pady=10)
    else:
        # Display Submit Payment button only if no payment exists
        def submit_payment():
            try:
                conn = databasejoin()
                cursor = conn.cursor()

                cursor.execute("""
                    INSERT INTO Payments (User_ID, Payment_Date, Amount, Status, Membership_Type, Membership_ID)
                    VALUES (%s, CURDATE(), %s, 'Pending', %s, %s)
                """, (user_id, membership_cost, membership_type, membership_id))
                conn.commit()
                conn.close()

                messagebox.showinfo("Payment Submitted", "Your payment has been submitted and is pending approval.")
                payment_history.destroy()
                PaymentHistoryWindow(user_id)  # Refresh payment history window
            except Exception as e:
                messagebox.showerror("Database Error", f"Error submitting payment: {e}")

        ctk.CTkButton(payment_history, text="Submit Payment", command=submit_payment).pack(pady=20)

    # Go Back Button
    def payback():
        payment_history.destroy()
        dashboard.deiconify()

    ctk.CTkButton(payment_history, text="Go Back", command=payback).pack(pady=20)

def UserInfoWindow(user_id):  # This function displays the info of the Users
    global dashboard
    dashboard.withdraw()

    try:
        conn = databasejoin()
        cursor = conn.cursor()
        cursor.execute("""
            SELECT u.First_Name, u.Last_Name, u.Address, u.Phone, m.Membership_Type, m.Membership_Duration, t.Trainer_Name, u.Status
            FROM Users u 
            LEFT JOIN Memberships m ON u.Membership_ID = m.Membership_ID 
            LEFT JOIN Trainers t ON u.Trainer_ID = t.Trainer_ID
            WHERE u.User_ID = %s """, (user_id,))
        user_info = cursor.fetchone()
        conn.close()
    except Exception as e:
        messagebox.showerror("Database Error", f"Error fetching user information: {e}")
        return

    if not user_info:
        messagebox.showerror("Data Error", "No information found for this user.")
        return

    # Set the membership duration text based on the value
    membership_duration = user_info[5]
    if membership_duration == 1:
        membership_duration_text = "1 day"
    elif membership_duration > 1 and membership_duration <= 31:
        membership_duration_text = f"{membership_duration} days"
    else:
        membership_duration_text = f"{membership_duration // 30} months"

    full_name = f"{user_info[0]} {user_info[1]}"

    # Add the User Status (from the 'Status' column in Users table)
    labels = ["Full Name", "Address", "Phone", "Membership Type", "Membership Duration", "Trainer Name", "Membership Status", "User Status"]
    values = [full_name, user_info[2], user_info[3], user_info[4], membership_duration_text, user_info[6], user_info[4], user_info[7]]
    data = [(label, value) for label, value in zip(labels, values)]

    # Create the info window
    info_window = ctk.CTkToplevel(app)
    info_window.geometry("600x400")
    info_window.resizable(False, False)
    info_window.title("User Information")

    # Center the window
    screen_width = app.winfo_screenwidth()
    screen_height = app.winfo_screenheight()
    x = (screen_width // 2) - (600 // 2)
    y = (screen_height // 2) - (400 // 2)
    info_window.geometry(f"600x400+{x}+{y}")

    ctk.CTkLabel(info_window, text="User Information", font=("Helvetica", 16, "bold"), anchor="center").pack(pady=(10, 5))

    # Create the Treeview to display user info
    tree_frame = ctk.CTkFrame(info_window)
    tree_frame.pack(pady=10, padx=10, fill="both", expand=True)

    scrollbar = ttk.Scrollbar(tree_frame, orient="vertical")
    scrollbar.pack(side="right", fill="y")

    tree = ttk.Treeview(tree_frame, columns=("Attribute", "Value"), show="headings", yscrollcommand=scrollbar.set)
    tree.pack(fill="both", expand=True)

    scrollbar.config(command=tree.yview)

    tree.heading("Attribute", text=" ", anchor="center")
    tree.heading("Value", text="Information", anchor="center")

    tree.column("Attribute", anchor="w", width=200)
    tree.column("Value", anchor="w", width=400)

    # Insert data into the Treeview
    for label, value in data:
        tree.insert("", "end", values=(label, value))

    # Back button to return to the dashboard
    def infoback(info_window):
        info_window.destroy()  # Close the info_window
        dashboard.deiconify()  # Show the dashboard window again

    ctk.CTkButton(info_window, text="Go Back", command=lambda: infoback(info_window)).pack(pady=20)

def ExerciseLogWindow(user_id):# This functions allows the user to Log their exercises as well as view their Logs
    log_window = ctk.CTkToplevel(app)
    log_window.geometry("500x400")
    log_window.resizable(False,False)
    log_window.title("Exercise Log")

    ctk.CTkLabel(log_window, text="Log Your Exercise", font=("Helvetica", 18)).pack(pady=10)

    equipment_label = ctk.CTkLabel(log_window, text="Select Equipment:")
    equipment_label.pack(pady=(10, 0))
    equipment_menu = ctk.CTkOptionMenu(log_window, values=["Treadmill", "Dumbbells", "Barbell", "Bench"])
    equipment_menu.pack(pady=5)

    set_entry = ctk.CTkEntry(log_window, placeholder_text="Sets", width=200)
    set_entry.pack(pady=5)
    reps_entry = ctk.CTkEntry(log_window, placeholder_text="Reps", width=200)
    reps_entry.pack(pady=5)

def equipmentNames():
    """Fetch equipment details from the database."""
    try:
        conn = databasejoin()
        cursor = conn.cursor()
        # Fetch equipment names and statuses
        cursor.execute("SELECT Equipment_ID, Equipment_Name, Status FROM Equipments")
        equipment_data = cursor.fetchall()
        conn.close()
        return equipment_data  # Returns a list of tuples: [(id, "Treadmill", "Available"), ...]
    except Exception as e:
        messagebox.showerror("Database Error", f"Error fetching equipment data: {e}")
        return []

def ExerciseLogWindow(user_id):
    """Exercise log window to log and view exercises."""
    global dashboard
    dashboard.withdraw()  # Hide the dashboard window
    global equipment_menu, set_entry, reps_entry, log_window
    log_window = ctk.CTkToplevel(app)
    log_window.resizable(False, False)
    log_window.geometry("600x600")
    log_window.title("Exercise Log")

    # Center the window
    screen_width = app.winfo_screenwidth()
    screen_height = app.winfo_screenheight()
    x = (screen_width // 2) - (600 // 2)
    y = (screen_height // 2) - (600 // 2)
    log_window.geometry(f"600x600+{x}+{y}")

    ctk.CTkLabel(log_window, text="Log Your Exercise", font=("Helvetica", 18)).pack(pady=10)

    try:
        conn = databasejoin()
        cursor = conn.cursor()

        # Check account status
        cursor.execute("SELECT Status FROM Users WHERE User_ID = %s", (user_id,))
        account_status = cursor.fetchone()

        if account_status and account_status[0] in ['Expired', 'Suspended']:
            messagebox.showerror("Account Inactive", "Your account is either expired or suspended. You cannot log exercises.")
            conn.close()
            log_window.destroy()  # Close the log window
            dashboard.deiconify()  # Show the main dashboard window again
            return

        conn.close()

    except Exception as e:
        messagebox.showerror("Database Error", f"Error checking account status: {e}")
        log_window.destroy()  # Close the log window in case of an error
        dashboard.deiconify()  # Show the main dashboard window again
        return

    ctk.CTkLabel(log_window, text="Select Equipment:").pack(pady=(10, 0))

    # Fetch equipment data and filter for available equipment
    equipment_data = equipmentNames()
    if not equipment_data:
        messagebox.showerror("Error", "No equipment data found in the system.")
        return

    available_equipment = [name for _, name, status in equipment_data if status == "Available"]
    equipment_status = {name: status for _, name, status in equipment_data}

    if not available_equipment:
        messagebox.showerror("Error", "No equipment is currently available.")
        return

    equipment_menu = ctk.CTkOptionMenu(log_window, values=available_equipment)
    equipment_menu.pack(pady=5)

    # Input Fields
    set_entry = ctk.CTkEntry(log_window, placeholder_text="Sets", width=200)
    set_entry.pack(pady=5)
    reps_entry = ctk.CTkEntry(log_window, placeholder_text="Reps", width=200)
    reps_entry.pack(pady=5)

    def log_exercise():
        """Logs the exercise if the equipment is available."""
        equipment_name = equipment_menu.get()
        sets = set_entry.get()
        reps = reps_entry.get()

        if not equipment_name or not sets or not reps:
            messagebox.showerror("Input Error", "Please fill in all fields.")
            return

        if not sets.isdigit() or not reps.isdigit():
            messagebox.showerror("Input Error", "Sets and Reps must be numeric.")
            return

        # Check the equipment status
        if equipment_status[equipment_name] != "Available":
            messagebox.showerror(
                "Unavailable Equipment",
                f"The selected equipment '{equipment_name}' is currently {equipment_status[equipment_name]}."
            )
            return

        try:
            conn = databasejoin()
            cursor = conn.cursor()

            # Fetch Equipment_ID
            cursor.execute("SELECT Equipment_ID FROM Equipments WHERE Equipment_Name = %s", (equipment_name,))
            result = cursor.fetchone()
            if not result:
                messagebox.showerror("Error", f"Equipment '{equipment_name}' not found.")
                return

            equipment_id = result[0]

            # Log the exercise
            cursor.execute("""
                INSERT INTO Exercise_Log (User_ID, Equipment_ID, Equipment_Name, Sets, Reps, log_date)
                VALUES (%s, %s, %s, %s, %s, NOW())
            """, (user_id, equipment_id, equipment_name, int(sets), int(reps)))
            conn.commit()
            conn.close()

            messagebox.showinfo("Success", "Exercise logged successfully!")
            set_entry.delete(0, tk.END)
            reps_entry.delete(0, tk.END)
            load_logged_exercises()

        except Exception as e:
            messagebox.showerror("Database Error", f"Error logging exercise: {e}")

    ctk.CTkButton(log_window, text="Log Workout", command=log_exercise).pack(pady=10)

    # Logged Exercises Section
    ctk.CTkLabel(log_window, text="Your Logged Exercises", font=("Helvetica", 16)).pack(pady=10)

    # Treeview for Logged Exercises
    columns = ("log_date", "equipment_name", "sets", "reps")
    exercise_tree = ttk.Treeview(log_window, columns=columns, show="headings", height=10)
    exercise_tree.heading("log_date", text="Log Date")
    exercise_tree.heading("equipment_name", text="Equipment Name")
    exercise_tree.heading("sets", text="Sets")
    exercise_tree.heading("reps", text="Reps")

    exercise_tree.column("log_date", width=150, anchor="center")
    exercise_tree.column("equipment_name", width=150, anchor="center")
    exercise_tree.column("sets", width=100, anchor="center")
    exercise_tree.column("reps", width=100, anchor="center")
    exercise_tree.pack(pady=10, fill="both", expand=True)

    # Add a scrollbar to the Treeview
    scrollbar = ttk.Scrollbar(log_window, orient="vertical", command=exercise_tree.yview)
    exercise_tree.config(yscrollcommand=scrollbar.set)
    scrollbar.pack(side="right", fill="y")

    def load_logged_exercises():
        """Load and display the user's logged exercises."""
        for row in exercise_tree.get_children():
            exercise_tree.delete(row)

        try:
            conn = databasejoin()
            cursor = conn.cursor()
            cursor.execute("""
                SELECT log_date, Equipment_Name, Sets, Reps
                FROM Exercise_Log
                WHERE User_ID = %s
                ORDER BY log_date DESC
            """, (user_id,))
            logged_exercises = cursor.fetchall()
            conn.close()

            for exercise in logged_exercises:
                exercise_tree.insert("", "end", values=exercise)

        except Exception as e:
            messagebox.showerror("Database Error", f"Error fetching logged exercises: {e}")

    # Load exercises on window creation
    load_logged_exercises()

    # Back Button
    def back_to_dashboard():
        log_window.destroy()  # Close the exercise log window
        dashboard.deiconify()  # Show the dashboard window again

    ctk.CTkButton(log_window, text="Go Back", command=back_to_dashboard).pack(pady=10)

#-----------------------------LOGIN---------------------------------#
def UserLogin(): # This is the login function gets the username and password of the user to enter the User Dashboard
    username = usern.get()
    password = passw.get()

    # Check if both username and password are provided
    if not username or not password:
        messagebox.showerror("Input Error", "Please enter both username and password.")
        return

    try:
        conn = databasejoin()
        cursor = conn.cursor()

        # Use BINARY to ensure case-sensitive comparison
        cursor.execute("""
            SELECT User_ID 
            FROM Users 
            WHERE BINARY User_Name = %s AND BINARY Pass_word = %s
        """, (username, password))
        user = cursor.fetchone()
        conn.close()

        # Check if user exists
        if user:
            messagebox.showinfo("Login Success", "Welcome!")
            app.withdraw()
            UserDashboard(user[0])
        else:
            messagebox.showerror("Login Error", "Invalid username or password.")
    except Exception as e:
        messagebox.showerror("Database Error", f"Error logging in: {e}")
#--------------------------FUNCTION FOR REGISTERING--------------------------#
def regwindow():# This function is for the user to register their accounts
    def userreg():
        # Fetch input data from the registration form
        firstname = firstname_entry.get()
        lastname = lastname_entry.get()
        username = username_entry.get()
        password = password_entry.get()
        password1 = password1_entry.get()
        age = age_entry.get()
        email = email_entry.get()
        address = address_entry.get()
        phone = phone_entry.get()
        trainer_selection = trainer_menu.get()
        membership_selection = membership_menu.get()

        # Validate input fields
        if not all([firstname, lastname, username, password, password1, age, email, address, phone]):
            messagebox.showerror("Input Error", "Please fill in all fields.")
            return

        if password != password1:
            messagebox.showerror("Password Error", "Passwords do not match.")
            return

        try:
            age = int(age)
        except ValueError:
            messagebox.showerror("Input Error", "Please enter a valid age.")
            return

        # Get Trainer_ID if selected
        trainer_id = None
        if trainer_selection != "No Trainers Available":
            trainer_id = int(trainer_selection.split(" - ")[0])  # Extract Trainer_ID from selection

        # Validate and retrieve membership details
        if not memberships:
            messagebox.showerror("Membership Error", "No memberships available. Please contact support.")
            return

        membership_data = next(
            (m for m in memberships if f"{m[1]} ({format_duration(m[2])}, ₱{m[3]:,.2f})" == membership_selection), None
        )

        if membership_data:
            membership_id, _, membership_duration, membership_price = membership_data
        else:
            messagebox.showerror("Membership Error", "Please select a valid membership.")
            return

        try:
            # Step 1: Insert user data into the Users table
            conn = databasejoin()
            cursor = conn.cursor()

            # Check if the username already exists
            cursor.execute("SELECT * FROM Users WHERE User_Name = %s", (username,))
            if cursor.fetchone():
                messagebox.showerror("Username Error", "Username already exists.")
                conn.close()
                return

            cursor.execute("""
                INSERT INTO Users (First_Name, Last_Name, User_Name, Pass_word, Age, Email, Address, Phone, Trainer_ID, Membership_ID)
                VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
            """, (firstname, lastname, username, password, age, email, address, phone, trainer_id, membership_id))
            conn.commit()

            # Step 2: Retrieve the newly created User_ID
            user_id = cursor.lastrowid

            # Step 3: Insert data into the User_Memberships table
            membership_start_date = datetime.date.today()
            cursor.execute("""
                INSERT INTO User_Memberships (User_ID, Membership_ID, Membership_Start_Date, Membership_Duration, Status)
                VALUES (%s, %s, %s, %s, 'Active')
            """, (user_id, membership_id, membership_start_date, membership_duration))
            conn.commit()

            # Close the connection
            conn.close()

            messagebox.showinfo("Registration Success", "You have successfully registered!")
            windowreg.destroy()

        except Exception as e:
            messagebox.showerror("Database Error", f"Error during registration: {e}")

    windowreg = ctk.CTkToplevel(app)
    windowreg.geometry("500x650")
    windowreg.resizable(False, False)
    windowreg.title("Register: Time4Fitness")

    screen_width = windowreg.winfo_screenwidth()
    screen_height = windowreg.winfo_screenheight()
    x = (screen_width // 2) - (500 // 2)
    y = (screen_height // 2) - (650 // 2)
    windowreg.geometry(f"500x650+{x}+{y}")

    backimg = tk.PhotoImage(file="assets/REGISTER.png")
    windowreg.backimg = backimg
    backlabel = tk.Label(windowreg, image=backimg)
    backlabel.place(relwidth=1, relheight=1)

    firstname_entry = ctk.CTkEntry(windowreg, placeholder_text="First Name", width=300)
    firstname_entry.pack(pady=(115, 5))
    lastname_entry = ctk.CTkEntry(windowreg, placeholder_text="Last Name", width=300)
    lastname_entry.pack(pady=5)
    username_entry = ctk.CTkEntry(windowreg, placeholder_text="Username", width=300)
    username_entry.pack(pady=5)
    password_entry = ctk.CTkEntry(windowreg, placeholder_text="Password", show="*", width=300)
    password_entry.pack(pady=5)
    password1_entry = ctk.CTkEntry(windowreg, placeholder_text="Re-enter Password", show="*", width=300)
    password1_entry.pack(pady=5)
    age_entry = ctk.CTkEntry(windowreg, placeholder_text="Age", width=300)
    age_entry.pack(pady=5)
    email_entry = ctk.CTkEntry(windowreg, placeholder_text="Email Address", width=300)
    email_entry.pack(pady=5)
    address_entry = ctk.CTkEntry(windowreg, placeholder_text="Address", width=300)
    address_entry.pack(pady=5)
    phone_entry = ctk.CTkEntry(windowreg, placeholder_text="Phone Number", width=300)
    phone_entry.pack(pady=5)

    try:
        conn = databasejoin()
        cursor = conn.cursor()

        cursor.execute("SELECT Trainer_ID, Trainer_Name, Trainer_Specialization FROM Trainers")
        trainers = cursor.fetchall()
        trainer_menu_values = [f"{trainer_id} - {name} - {specialization}" for trainer_id, name, specialization in trainers]

        cursor.execute("SELECT Membership_ID, Membership_Type, Membership_Duration, Membership_Cost FROM Memberships WHERE Status = 'Active'")
        memberships = cursor.fetchall()

        def format_duration(days):
            # Special case for the Basic Package
            if days == 1:  
                return "1 Day"  # Treat 1 day in the database as 1 Month
            elif days == 30:
                return "1 Month"
            elif days == 90:
                return "3 Months"
            elif days == 180:
                return "6 Months"
            else:
                months = days // 30
                return f"{months} Month{'s' if months > 1 else ''}"

        membership_menu_values = [
            f"{membership_type} ({format_duration(duration)}, ₱{cost:,.2f})"
            for _, membership_type, duration, cost in memberships
        ]
        conn.close()
    except Exception as e:
        messagebox.showerror("Database Error", f"Error fetching memberships: {e}")
        memberships = []

    trainer_menu = ctk.CTkOptionMenu(
        windowreg,
        values=trainer_menu_values if trainer_menu_values else ["No Trainers Available"],
        width=300,
        text_color="Black",
        fg_color="white",
    )
    trainer_menu.pack(pady=5)
    trainer_menu.set("Select Trainer")

    membership_menu = ctk.CTkOptionMenu(
        windowreg,
        values=membership_menu_values if membership_menu_values else ["No Memberships Available"],
        width=300,
        text_color="Black",
        fg_color="white",
    )
    membership_menu.pack(pady=5)
    membership_menu.set("Select Membership Plan")

    register_button = ctk.CTkButton(
        windowreg, text="Register", text_color="Black", fg_color="white", command=userreg)
    register_button.pack(pady=20)

    trainer_menu.lift()
    membership_menu.lift()
    register_button.lift()
#-------------------------------ADMIN DASHBOARD ------------------------------#
def admin_UserLogin():# This function is exclusive for admins only
    """Admin Dashboard with functionalities to manage users."""
    admin_win = ctk.CTkToplevel(app)
    admin_win.resizable(False,False)
    admin_win.geometry("800x600")
    admin_win.title("Admin Dashboard")

    screen_width = admin_win.winfo_screenwidth()    #This line is to center the window
    screen_height = admin_win.winfo_screenheight()
    x = (screen_width // 2) - (800 // 2)
    y = (screen_height // 2) - (600 // 2)
    admin_win.geometry(f"800x600+{x}+{y}")

    ctk.CTkLabel(admin_win, text="Admin Dashboard", font=("Helvetica", 20)).pack(pady=20)

    # Frame for Treeview and scrollbar
    tree_frame = ctk.CTkFrame(admin_win)
    tree_frame.pack(pady=10, fill="both", expand=True)

    # Add Treeview
    columns = ("user_id", "first_name", "last_name", "membership_type", "membership_cost", "status")
    user_tree = ttk.Treeview(tree_frame, columns=columns, show="headings", height=15)

    # Define headings
    user_tree.heading("user_id", text="User ID")
    user_tree.heading("first_name", text="First Name")
    user_tree.heading("last_name", text="Last Name")
    user_tree.heading("membership_type", text="Membership Type")
    user_tree.heading("membership_cost", text="Cost")
    user_tree.heading("status", text="Status")

    # Define column widths
    user_tree.column("user_id", width=70, anchor="center")
    user_tree.column("first_name", width=120, anchor="center")
    user_tree.column("last_name", width=120, anchor="center")
    user_tree.column("membership_type", width=150, anchor="center")
    user_tree.column("membership_cost", width=100, anchor="center")
    user_tree.column("status", width=100, anchor="center")

    # Add scrollbar
    scrollbar = ttk.Scrollbar(tree_frame, orient="vertical", command=user_tree.yview)
    user_tree.configure(yscrollcommand=scrollbar.set)
    scrollbar.pack(side="right", fill="y")
    user_tree.pack(fill="both", expand=True)

    def load_users():
        """Load active users into the Treeview."""
        for row in user_tree.get_children():
            user_tree.delete(row)

        try:
            conn = databasejoin()
            cursor = conn.cursor()

            cursor.execute("""
                SELECT u.User_ID, u.First_Name, u.Last_Name, m.Membership_Type, m.Membership_Cost, u.Status 
                FROM Users u
                LEFT JOIN Memberships m ON u.Membership_ID = m.Membership_ID
            """)
            users = cursor.fetchall()
            conn.close()

            for user in users:
                user_tree.insert("", "end", values=user)

        except Exception as e:
            messagebox.showerror("Database Error", f"Error loading users: {e}")

    def approve_payment():
        """Approve the user's pending payment."""
        selected_item = user_tree.selection()
        if not selected_item:
            messagebox.showwarning("Selection Error", "Please select a user to approve payment.")
            return

        user_id = user_tree.item(selected_item[0], "values")[0]
        try:
            conn = databasejoin()
            cursor = conn.cursor()

            # Check if there is a pending payment for this user
            cursor.execute("""
                SELECT Payment_ID 
                FROM Payments 
                WHERE User_ID = %s AND Status = 'Pending'
            """, (user_id,))
            pending_payment = cursor.fetchone()

            if not pending_payment:
                messagebox.showerror("Payment Error", "No pending payment found for this user.")
                conn.close()
                return

            # Approve the pending payment
            cursor.execute("""
                UPDATE Payments
                SET Status = 'Approved'
                WHERE User_ID = %s AND Status = 'Pending'
            """, (user_id,))
            conn.commit()
            conn.close()
            messagebox.showinfo("Success", "Payment approved!")
            load_users()
        except Exception as e:
            messagebox.showerror("Database Error", f"Error approving payment: {e}")

    def update_status():
        """Update the status of the selected user."""
        selected_item = user_tree.selection()
        if not selected_item:
            messagebox.showwarning("Selection Error", "Please select a user to update status.")
            return

        user_id = user_tree.item(selected_item[0], "values")[0]
        new_status = status_menu.get()

        try:
            conn = databasejoin()
            cursor = conn.cursor()
            cursor.execute("""
                UPDATE Users
                SET Status = %s
                WHERE User_ID = %s
            """, (new_status, user_id))
            conn.commit()
            conn.close()
            messagebox.showinfo("Success", f"User status updated to {new_status}!")
            load_users()
        except Exception as e:
            messagebox.showerror("Database Error", f"Error updating status: {e}")

    def delete_user():
        """Delete a selected user and archive them in the Deleted_Users table."""
        selected_item = user_tree.selection()
        if not selected_item:
            messagebox.showwarning("Selection Error", "Please select a user to delete.")
            return

        user_id = user_tree.item(selected_item[0], "values")[0]  # Get the User_ID from the selected row

        try:
            conn = databasejoin()
            cursor = conn.cursor()

            # Fetch user data before deleting
            cursor.execute("""
                SELECT User_ID, First_Name, Last_Name, User_Name, Pass_word, Age, Email, Address, Phone, Trainer_ID, Membership_ID
                FROM Users
                WHERE User_ID = %s
            """, (user_id,))
            user_data = cursor.fetchone()

            if not user_data:
                messagebox.showerror("Error", "User not found in the database.")
                return

            # Insert user data into Deleted_Users
            cursor.execute("""
                INSERT INTO Deleted_Users 
                (User_ID, First_Name, Last_Name, User_Name, Pass_word, Age, Email, Address, Phone, Trainer_ID, Membership_ID, Deletion_Date)
                VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, NOW())
            """, user_data)

            # Delete dependent records from related tables
            cursor.execute("DELETE FROM Payments WHERE User_ID = %s", (user_id,))
            cursor.execute("DELETE FROM Attendance WHERE User_ID = %s", (user_id,))
            cursor.execute("DELETE FROM User_Memberships WHERE User_ID = %s", (user_id,))

            # Remove the user from the Users table
            cursor.execute("DELETE FROM Users WHERE User_ID = %s", (user_id,))
            conn.commit()
            conn.close()

            messagebox.showinfo("Success", "User deleted and archived.")
            load_users()  # Refresh the user list

        except Exception as e:
            messagebox.showerror("Database Error", f"Error deleting user: {e}")

    def view_user_info():
        """View detailed information about a selected user."""
        selected_item = user_tree.selection()
        if not selected_item:
            messagebox.showwarning("Selection Error", "Please select a user to view their information.")
            return

        user_id = user_tree.item(selected_item[0], "values")[0]
        try:
            conn = databasejoin()
            cursor = conn.cursor()
            cursor.execute("""
                SELECT u.First_Name, u.Last_Name, u.Email, u.Phone, u.Address, m.Membership_Type, m.Membership_Cost
                FROM Users u
                LEFT JOIN Memberships m ON u.Membership_ID = m.Membership_ID
                WHERE u.User_ID = %s
            """, (user_id,))
            user_info = cursor.fetchone()
            conn.close()

            if not user_info:
                messagebox.showerror("Data Error", "No information found for this user.")
                return

            info_win = ctk.CTkToplevel(admin_win)
            info_win.resizable(False,False)
            info_win.geometry("400x300")
            info_win.title("User Information")

            screen_width = info_win.winfo_screenwidth()    #This line is to center the window
            screen_height = info_win.winfo_screenheight()
            x = (screen_width // 2) - (400 // 2)
            y = (screen_height // 2) - (300 // 2)
            info_win.geometry(f"400x300+{x}+{y}")

            labels = ["First Name", "Last Name", "Email", "Phone", "Address", "Membership Type", "Membership Cost"]
            for i, label in enumerate(labels):
                ctk.CTkLabel(info_win, text=f"{label}: {user_info[i]}", font=("Arial", 12)).pack(pady=5)

        except Exception as e:
            messagebox.showerror("Database Error", f"Error fetching user information: {e}")

    def view_deleted_users():
        """Open a window to view deleted users."""
        deleted_users_win = ctk.CTkToplevel(admin_win)
        deleted_users_win.resizable(False,False)
        deleted_users_win.geometry("1000x400")
        deleted_users_win.title("Deleted Users")

        screen_width = deleted_users_win.winfo_screenwidth()    #This line is to center the window
        screen_height = deleted_users_win.winfo_screenheight()
        x = (screen_width // 2) - (1000 // 2)
        y = (screen_height // 2) - (400 // 2)
        deleted_users_win.geometry(f"1000x400+{x}+{y}")

        columns = ("user_id", "first_name", "last_name", "user_name", "email", "pass_word", "deletion_date")
        deleted_tree = ttk.Treeview(deleted_users_win, columns=columns, show="headings")

        # Define headings
        deleted_tree.heading("user_id", text="User ID")
        deleted_tree.heading("first_name", text="First Name")
        deleted_tree.heading("last_name", text="Last Name")
        deleted_tree.heading("user_name", text="Username")
        deleted_tree.heading("email", text="Email")
        deleted_tree.heading("pass_word", text="Password")
        deleted_tree.heading("deletion_date", text="Deletion Date")

        # Define column widths
        deleted_tree.column("user_id", width=70, anchor="center")
        deleted_tree.column("first_name", width=120, anchor="center")
        deleted_tree.column("last_name", width=120, anchor="center")
        deleted_tree.column("user_name", width=120, anchor="center")
        deleted_tree.column("email", width=180, anchor="center")
        deleted_tree.column("pass_word", width=180, anchor="center")
        deleted_tree.column("deletion_date", width=150, anchor="center")

        deleted_tree.pack(fill="both", expand=True)

        try:
            conn = databasejoin()
            cursor = conn.cursor()

            # Fetch deleted user details
            cursor.execute("""
                SELECT User_ID, First_Name, Last_Name, User_Name, Email, Pass_word, Deletion_Date 
                FROM Deleted_Users
            """)
            deleted_users = cursor.fetchall()
            conn.close()

            # Insert deleted user data into the Treeview
            for user in deleted_users:
                deleted_tree.insert("", "end", values=user)

        except Exception as e:
            messagebox.showerror("Database Error", f"Error fetching deleted users: {e}")

    def manage_equipment():
            """Open a window to manage equipment."""
            equip_win = ctk.CTkToplevel(admin_win)
            equip_win.resizable(False,False)
            equip_win.geometry("700x400")
            equip_win.title("Manage Equipment")

            screen_width = equip_win.winfo_screenwidth()    #This line is to center the window
            screen_height = equip_win.winfo_screenheight()
            x = (screen_width // 2) - (600 // 2)
            y = (screen_height // 2) - (500 // 2)
            equip_win.geometry(f"600x500+{x}+{y}")
            # Frame for Treeview
            equip_frame = ctk.CTkFrame(equip_win)
            equip_frame.pack(pady=10, fill="both", expand=True)

            # Define columns
            columns = ("equipment_id", "equipment_name", "equipment_type", "status")
            equip_tree = ttk.Treeview(equip_frame, columns=columns, show="headings")

            # Define headings
            equip_tree.heading("equipment_id", text="Equipment ID")
            equip_tree.heading("equipment_name", text="Name")
            equip_tree.heading("equipment_type", text="Type")
            equip_tree.heading("status", text="Status")

            # Define column widths
            equip_tree.column("equipment_id", width=100, anchor="center")
            equip_tree.column("equipment_name", width=200, anchor="center")
            equip_tree.column("equipment_type", width=150, anchor="center")
            equip_tree.column("status", width=150, anchor="center")

            equip_tree.pack(fill="both", expand=True)

            def load_equipment():
                """Load equipment details into the Treeview."""
                for row in equip_tree.get_children():
                    equip_tree.delete(row)
                try:
                    conn = databasejoin()
                    cursor = conn.cursor()
                    cursor.execute("SELECT Equipment_ID, Equipment_Name, Equipment_Type, Status FROM Equipments")
                    equipment = cursor.fetchall()
                    conn.close()
                    for equip in equipment:
                        equip_tree.insert("", "end", values=equip)
                except Exception as e:
                    messagebox.showerror("Database Error", f"Error loading equipment: {e}")

            def update_equipment_status():
                """Update the status of selected equipment."""
                selected_item = equip_tree.selection()
                if not selected_item:
                    messagebox.showwarning("Selection Error", "Please select equipment to update its status.")
                    return

                equipment_id = equip_tree.item(selected_item[0], "values")[0]
                new_status = status_menu.get()

                try:
                    conn = databasejoin()
                    cursor = conn.cursor()
                    cursor.execute("""
                        UPDATE Equipments
                        SET Status = %s
                        WHERE Equipment_ID = %s
                    """, (new_status, equipment_id))
                    conn.commit()
                    conn.close()
                    messagebox.showinfo("Success", f"Equipment status updated to {new_status}!")
                    load_equipment()
                except Exception as e:
                    messagebox.showerror("Database Error", f"Error updating equipment status: {e}")

            # Dropdown for equipment status
            status_menu = ttk.Combobox(equip_win, values=["Available", "In Maintenance", "Out of Order"], state="readonly")
            status_menu.pack(pady=5)

            # Update Button
            ctk.CTkButton(equip_win, text="Update Equipment Status", command=update_equipment_status).pack(pady=5)

            load_equipment()

    # Dropdown for status update
    status_menu = ttk.Combobox(admin_win, values=["Active", "Expired", "Suspended"], state="readonly")
    status_menu.pack(pady=5)

    # Buttons
    buttons_frame = ctk.CTkFrame(admin_win)
    buttons_frame.pack(pady=10)

    ctk.CTkButton(buttons_frame, text="Approve Payment", command=approve_payment).pack(side="left", padx=5)
    ctk.CTkButton(buttons_frame, text="Update Status", command=update_status).pack(side="left", padx=5)
    ctk.CTkButton(buttons_frame, text="Delete User", command=delete_user).pack(side="left", padx=5)
    ctk.CTkButton(buttons_frame, text="User Information", command=view_user_info).pack(side="left", padx=5)
    ctk.CTkButton(buttons_frame, text="View Deleted Users", command=view_deleted_users).pack(side="left", padx=5)
    ctk.CTkButton(admin_win, text="Manage Equipment", command=manage_equipment).pack(pady=10)
    
    def BacktoMain():
        """Log out the admin and return to the main application."""
        if admin_win:
            admin_win.destroy()  # Close the admin window
            messagebox.showinfo("Logout", "You have been logged out.")  # Inform the admin about the logout
        app.deiconify()  # Show the main application window
        Loginclearinput()  # Clear any existing input for login


    ctk.CTkButton(admin_win, text="Log-out", width=200, command=BacktoMain).pack(pady=10)
    
    load_users()

def adminLogin():#This function gets the admin username and password to etner the admin Dashboard
    """Admin login with case-sensitive validation."""
    admin_username = usern.get()
    admin_password = passw.get()

    # Check case-sensitive admin credentials
    if admin_username == "admin" and admin_password == "admin":
        messagebox.showinfo("Success", "Admin login successful!")
        admin_UserLogin()  # Open the admin dashboard
    else:
        messagebox.showerror("Error", "Invalid admin credentials. Please try again.")
        clear_inputs()

#--------------------------------MAIN WINDOW---------------------------------#
app = ctk.CTk()
app.geometry("825x550")
app.resizable(False,False)
app.title("Time4Fitness")

screen_width = app.winfo_screenwidth()
screen_height = app.winfo_screenheight()

x = (screen_width // 2) - (825 // 2)
y = (screen_height // 2) - (550 // 2)
app.geometry(f"825x550+{x}+{y}")

Backg = tk.PhotoImage(file="assets/Time4Fitness.png") #Importing Image
labelbg = tk.Label(app, image=Backg)
labelbg.place(relwidth=1, relheight=1)

title = ctk.CTkFont(family="Lato", size=35, weight="bold")

frame = ctk.CTkFrame(app, width=400, height=300, fg_color="gray")
frame.place(relx=0.75, rely=0.53, anchor="center")

label1 = ctk.CTkLabel(frame, text="WELCOME\nGYM MEMBERS", font=("Helvetica", 25), text_color="white")
label1.grid(row=0, column=0, padx=10, pady=20)

def clear_inputs(): #This is to clear the input in the username and Password that has inputed.
    """Clear the username and password fields."""
    usern.delete(0, tk.END)
    passw.delete(0, tk.END)

usern = ctk.CTkEntry(frame, placeholder_text="Username", width=250, corner_radius=10)
usern.grid(row=1, column=0, padx=10, pady=10)

passw = ctk.CTkEntry(frame, placeholder_text="Password", show="*", width=250, corner_radius=10)
passw.grid(row=2, column=0, padx=10, pady=10)

login = ctk.CTkButton(frame, text="Login", width=250, text_color="black" ,fg_color="white", corner_radius=10, command=UserLogin)
login.grid(row=3, column=0, padx=10, pady=7)

adminLogin = ctk.CTkButton(frame, text="Admin Login", width=250, text_color="black", fg_color="white", corner_radius=10, command=adminLogin)
adminLogin.grid(row=4, column=0, padx=10, pady=5)

label2 = ctk.CTkLabel(frame, text="Don't have an account yet? ", text_color="white", font=("Arial", 12))
label2.grid(row=5, column=0, padx=36, pady=(10, 5), sticky="w")

labelreg = ctk.CTkLabel(frame, text="Register", text_color="white", font=("Arial", 12, "underline"))
labelreg.grid(row=5, column=0, padx=(185, 10), pady=(10, 5), sticky="w")
labelreg.bind("<Button-1>", lambda e: regwindow())

app.mainloop()