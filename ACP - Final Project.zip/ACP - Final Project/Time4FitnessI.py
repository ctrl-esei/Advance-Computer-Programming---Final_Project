import datetime
import tkinter as tk
from PIL import Image
import mysql.connector
from tkinter import ttk
import customtkinter as ctk
from tkinter import messagebox
#-----------------------------DATABASE FUNCTION-----------------------------#
def databasejoin(): #This is to enter the database named FitnessDB
    return mysql.connector.connect(
        host="localhost",
        user="root",
        password="",
        database="FitnessDB"
    )
#-----------------------------USER DASHBOARD--------------------------------#
def UserDashboard(user_id): #This function is to display the User Interface
    global dashboard
    dashboard = ctk.CTkToplevel(app)
    dashboard.geometry("600x500")
    dashboard.resizable(False,False)
    dashboard.title("User Dashboard")

    screen_width = dashboard.winfo_screenwidth()    #This line is to center the window (Not working sa Windows)
    screen_height = dashboard.winfo_screenheight()
    x = (screen_width // 2) - (600 // 2)
    y = (screen_height // 2) - (500 // 2)
    dashboard.geometry(f"600x500+{x}+{y}")

    Backimage = Image.open("assets/WELCOME.png") 
    Backim = ctk.CTkImage(light_image=Backimage, size=(600, 500))
    backlabel = ctk.CTkLabel(dashboard, image=Backim, text="")
    backlabel.place(relwidth=1, relheight=1)

    pastel_orange = "#FAD4B7"

    ctk.CTkLabel(dashboard,text="Welcome to Your Dashboard",font=("Helvetica", 20, "bold"),text_color=pastel_orange).pack(pady=20)

    button_width = 220
    button_height = 40 
    button_font = ("Helvetica", 14)

    user_info_button = ctk.CTkButton(dashboard,text="User Information", width=button_width, height=button_height, font=button_font, fg_color=pastel_orange, text_color="black", command=lambda: UserInfoWindow(user_id))
    user_info_button.pack(pady=10)

    exercise_log_button = ctk.CTkButton(dashboard, text="Exercise Log", width=button_width, height=button_height, font=button_font, fg_color=pastel_orange, text_color="black", command=lambda: ExerciseLogWindow(user_id))
    exercise_log_button.pack(pady=10)

    attendance_button = ctk.CTkButton(dashboard, text="Attendance", width=button_width, height=button_height, font=button_font, fg_color=pastel_orange, text_color="black", command=lambda: attendance_window(user_id))
    attendance_button.pack(pady=10)

    payment_history_button = ctk.CTkButton(dashboard, text="Payment", width=button_width, height=button_height, font=button_font, fg_color=pastel_orange, text_color="black", command=lambda: PaymentHistoryWindow(user_id))
    payment_history_button.pack(pady=10)

    Logout_button = ctk.CTkButton(dashboard, text="Log-out", width=button_width, height=button_height, font=button_font, fg_color=pastel_orange, text_color="black", command=backtoLogin)
    Logout_button.pack(pady=10)

def Loginclearinput():  #this is to clear all the login informations that the user or admin will input in the username and password
    usern.delete(0, tk.END)
    passw.delete(0, tk.END)

def backtoLogin(): #This function is designed for the user to logged them out of their dashboard
    global dashboard
    if dashboard:
        dashboard.destroy()
        dashboard = None
        messagebox.showinfo("Logout", "You have been logged out.") 
    Loginclearinput()
    app.deiconify()

def attendance_window(user_id): # This function handles the attendance window
    global dashboard
    dashboard.withdraw()

    attendance = ctk.CTkToplevel(app)
    attendance.geometry("500x600")
    attendance.resizable(False, False)
    attendance.title("Attendance")

    ctk.CTkLabel(attendance, text="Attendance Check-In", font=("Helvetica", 18)).pack(pady=20)

    screen_width = app.winfo_screenwidth()
    screen_height = app.winfo_screenheight()
    x = (screen_width // 2) - (500 // 2)
    y = (screen_height // 2) - (600 // 2)
    attendance.geometry(f"500x600+{x}+{y}")

    style = ttk.Style()
    style.theme_use("clam")
    style.configure("Treeview", font=("Century Gothic", 12), rowheight=25)
    style.configure("Treeview.Heading", font=("Century Gothic", 12, "bold"), foreground="black")
    style.map("Treeview.Heading", background=[("active", "#F4A460")], foreground=[("active", "black")])
    style.configure("Treeview.Heading", background="#FFDAB9")  
    try:
        conn = databasejoin()
        cursor = conn.cursor()

        today = datetime.date.today()

        # Check account status
        cursor.execute("SELECT Status FROM Users WHERE User_ID = %s", (user_id,))
        account_status = cursor.fetchone()

        if account_status and account_status[0] in ['Expired', 'Suspended']:
            messagebox.showerror("Account Inactive", "Your account is either expired or suspended. You cannot log attendance or exercises.")
            attendance.destroy()
            dashboard.deiconify()
            return

        cursor.execute(""" SELECT Attendance_ID FROM Attendance WHERE User_ID = %s AND Attendance_Date = %s """, (user_id, today))
        already_checked_in = cursor.fetchone()

        if already_checked_in:
            ctk.CTkLabel(attendance, text="You have already checked in today.", font=("Arial", 12), fg_color="green").pack(pady=10)
        else:
            def check_in():
                try:
                    conn = databasejoin()
                    cursor = conn.cursor()

                    check_in_time = datetime.datetime.now().time()
                    cursor.execute(""" INSERT INTO Attendance (User_ID, Attendance_Date, Check_In_Time, Status) VALUES (%s, %s, %s, 'Present') """, (user_id, today, check_in_time))
                    conn.commit()

                    cursor.close()
                    conn.close()

                    messagebox.showinfo("Success", "Check-in successful!")
                    attendance.destroy()
                    dashboard.deiconify()
                except Exception as e:
                    messagebox.showerror("Database Error", f"Error during check-in: {e}")

            ctk.CTkButton(attendance, text="Check In", command=check_in, fg_color="#FAD4B7", text_color="black").pack(pady=10)

        ctk.CTkLabel(attendance, text="Your Attendance Records:", font=("Arial", 14)).pack(pady=20)

        columns = ("attendance_date", "status")
        attendance_tree = ttk.Treeview(attendance, columns=columns, show="headings", height=10)

        tree_frame = ctk.CTkFrame(attendance)
        tree_frame.pack(pady=10, padx=10, fill="both", expand=True)

        columns = ("attendance_date", "status")
        attendance_tree = ttk.Treeview(tree_frame, columns=columns, show="headings", height=10)

        attendance_tree.heading("attendance_date", text="Attendance Date")
        attendance_tree.heading("status", text="Status")

        attendance_tree.column("attendance_date", width=150, anchor="center")
        attendance_tree.column("status", width=100, anchor="center")

        attendance_tree.grid(row=0, column=0, sticky="nsew")

        scrollbar = ttk.Scrollbar(tree_frame, orient="vertical", command=attendance_tree.yview)
        attendance_tree.configure(yscrollcommand=scrollbar.set)

        scrollbar.grid(row=0, column=1, sticky="ns")

        tree_frame.grid_rowconfigure(0, weight=1)
        tree_frame.grid_columnconfigure(0, weight=1)

        cursor.execute(""" SELECT Attendance_Date, Status FROM Attendance WHERE User_ID = %s """, (user_id,))
        attendance_data = cursor.fetchall()

        cursor.close()
        conn.close()

        if not attendance_data:
            ctk.CTkLabel(attendance, text="No attendance records found.", font=("Arial", 12)).pack(pady=10)
        else:
            for date, status in attendance_data:
                attendance_tree.insert("", "end", values=(date, status))

    except Exception as e:
        messagebox.showerror("Database Error", f"Error fetching attendance data: {e}")
        return
    
    def attendanceback():
        attendance.destroy()
        dashboard.deiconify()

    ctk.CTkButton(attendance, text="Go Back", command=attendanceback, fg_color="#FAD4B7", text_color="black").pack(pady=20)

def PaymentHistoryWindow(user_id):#This function hadles the payments of the user
    global dashboard
    dashboard.withdraw()

    payment_history = ctk.CTkToplevel(app)
    payment_history.geometry("600x500")
    payment_history.resizable(False, False)
    payment_history.title("Payment Section")

    screen_width = app.winfo_screenwidth()
    screen_height = app.winfo_screenheight()
    x = (screen_width // 2) - (600 // 2)
    y = (screen_height // 2) - (500 // 2)
    payment_history.geometry(f"600x500+{x}+{y}")

    ctk.CTkLabel(payment_history, text="Payment Details", font=("Helvetica", 18)).pack(pady=20)

    try:
        conn = databasejoin()
        cursor = conn.cursor()

        # Fetch membership and payment details
        cursor.execute("""
            SELECT m.Membership_ID, m.Membership_Type, m.Membership_Cost, m.Membership_Duration,
                   MAX(p.Payment_Date) AS Last_Payment_Date, p.Status, u.Status AS Membership_Status
            FROM Memberships m
            LEFT JOIN Payments p ON m.Membership_ID = p.Membership_ID AND p.User_ID = %s
            JOIN Users u ON u.Membership_ID = m.Membership_ID
            WHERE u.User_ID = %s
            GROUP BY m.Membership_ID
        """, (user_id, user_id))
        membership_info = cursor.fetchone()

        # Fetch payment history for the user
        cursor.execute("""
            SELECT Payment_Date, Amount, Status
            FROM Payments
            WHERE User_ID = %s
            ORDER BY Payment_Date DESC
        """, (user_id,))
        payment_history_data = cursor.fetchall()

        conn.close()
    except Exception as e:
        messagebox.showerror("Database Error", f"Error fetching membership information: {e}")
        return

    if not membership_info:
        ctk.CTkLabel(payment_history, text="No membership information found.", font=("Arial", 12)).pack(pady=10)
        return

    membership_id, membership_type, membership_cost, duration, last_payment_date, status, membership_status = membership_info
    today = datetime.date.today()

    # Calculate expiry date
    if last_payment_date:
        expiry_date = last_payment_date + datetime.timedelta(days=duration)
    else:
        # For new users, calculate expiry date based on the current date
        expiry_date = today + datetime.timedelta(days=duration)

    # Handle renewal scenario (new expiry date after renewal)
    if membership_status == "Renewed":
        # Calculate a new expiry date based on the renewal duration
        expiry_date = today + datetime.timedelta(days=duration)  # New expiry date after renewal
        membership_status_display = "Renewed"
    else:
        membership_status_display = "Active"

    # Display membership details
    ctk.CTkLabel(payment_history, text=f"Membership Type: {membership_type}", font=("Arial", 14)).pack(pady=5)
    ctk.CTkLabel(payment_history, text=f"Membership Cost: ₱{membership_cost:,.2f}", font=("Arial", 14)).pack(pady=5)

    if expiry_date:
        ctk.CTkLabel(payment_history, text=f"Membership Expiry Date: {expiry_date}", font=("Arial", 14)).pack(pady=5)
        if expiry_date < today:
            ctk.CTkLabel(payment_history, text="Status: EXPIRED", font=("Arial", 14), fg_color="red").pack(pady=10)
    else:
        ctk.CTkLabel(payment_history, text="Membership Expiry Date: Not available.", font=("Arial", 14)).pack(pady=5)

    # Treeview for Payment History
    tree_frame = ctk.CTkFrame(payment_history)
    tree_frame.pack(pady=10, padx=10, fill="both", expand=True)

    columns = ("Payment_Date", "Amount", "Status")
    payment_tree = ttk.Treeview(tree_frame, columns=columns, show="headings", height=5)

    # Configure Treeview headings
    payment_tree.heading("Payment_Date", text="Payment Date")
    payment_tree.heading("Amount", text="Amount")
    payment_tree.heading("Status", text="Status")

    # Configure Treeview columns
    payment_tree.column("Payment_Date", width=150, anchor="center")
    payment_tree.column("Amount", width=100, anchor="center")
    payment_tree.column("Status", width=100, anchor="center")

    payment_tree.grid(row=0, column=0, sticky="nsew")

    # Scrollbar for Treeview
    scrollbar = ttk.Scrollbar(tree_frame, orient="vertical", command=payment_tree.yview)
    payment_tree.configure(yscrollcommand=scrollbar.set)
    scrollbar.grid(row=0, column=1, sticky="ns")

    tree_frame.grid_rowconfigure(0, weight=1)
    tree_frame.grid_columnconfigure(0, weight=1)

    # Insert payment history data into the Treeview
    for payment in payment_history_data:
        payment_tree.insert("", "end", values=payment)

    # Apply custom style for the Treeview
    style = ttk.Style()
    style.theme_use("clam")
    style.configure("Treeview", font=("Century Gothic", 12), rowheight=25)
    style.configure("Treeview.Heading", font=("Century Gothic", 12, "bold"), foreground="black")
    style.map("Treeview.Heading", background=[("active", "#F4A460")], foreground=[("active", "black")])
    style.configure("Treeview.Heading", background="#FFDAB9")

    # Submit Payment Button Logic
    # Display submit payment button only for new users or if the membership is renewed and no pending payment exists
    if membership_status == "Renewed" and not any(payment[2] == "Pending" for payment in payment_history_data):
        ctk.CTkLabel(payment_history, text="Your membership has been renewed.", font=("Arial", 14), fg_color="#FFDAB9").pack(pady=10)

    # Check if it's a new user or a renewed user with no pending payment
    if not last_payment_date or (membership_status == "Renewed" and not any(payment[2] == "Pending" for payment in payment_history_data)):
        def submit_payment():
            try:
                conn = databasejoin()
                cursor = conn.cursor()

                # Insert payment record for new user or renewed membership
                cursor.execute("""
                    INSERT INTO Payments (User_ID, Membership_ID, Membership_Type, Payment_Date, Amount, Status)
                    VALUES (%s, %s, %s, NOW(), %s, 'Pending')
                """, (user_id, membership_id, membership_type, membership_cost))
                conn.commit()
                conn.close()

                messagebox.showinfo("Success", "Payment submitted successfully and sent to admin for approval.")
                payment_history.destroy()
                PaymentHistoryWindow(user_id)  # Reload payment history window
            except Exception as e:
                messagebox.showerror("Database Error", f"Error submitting payment: {e}")

        ctk.CTkButton(payment_history, text="Submit Payment", command=submit_payment).pack(pady=20)

    # Go Back Button
    def go_back():
        payment_history.destroy()
        dashboard.deiconify()

    ctk.CTkButton(payment_history, text="Go Back", command=go_back).pack(pady=20)

def UserInfoWindow(user_id):  # This function displays the info of the Users
    global dashboard
    dashboard.withdraw()

    try:
        conn = databasejoin()
        cursor = conn.cursor()
        cursor.execute(""" 
            SELECT u.First_Name, u.Last_Name, u.Address, u.Phone, m.Membership_Type, m.Membership_Duration, t.Trainer_Name, u.Status
            FROM Users u 
            LEFT JOIN Memberships m ON u.Membership_ID = m.Membership_ID 
            LEFT JOIN Trainers t ON u.Trainer_ID = t.Trainer_ID
            WHERE u.User_ID = %s """, (user_id,))
        user_info = cursor.fetchone()
        conn.close()
    except Exception as e:
        messagebox.showerror("Database Error", f"Error fetching user information: {e}")
        return

    if not user_info:
        messagebox.showerror("Data Error", "No information found for this user.")
        return

    membership_duration = user_info[5]
    if membership_duration == 1:
        membership_duration_text = "1 day"
    elif membership_duration > 1 and membership_duration <= 31:
        membership_duration_text = f"{membership_duration} days"
    else:
        membership_duration_text = f"{membership_duration // 30} months"

    full_name = f"{user_info[0]} {user_info[1]}"

    labels = ["Full Name", "Address", "Phone", "Membership Type", "Membership Duration", "Trainer Name", "Membership Status", "User Status"]
    values = [full_name, user_info[2], user_info[3], user_info[4], membership_duration_text, user_info[6], user_info[4], user_info[7]]
    data = [(label, value) for label, value in zip(labels, values)]

    info_window = ctk.CTkToplevel(app)
    info_window.geometry("600x400")
    info_window.resizable(False, False)
    info_window.title("User Information")

    screen_width = app.winfo_screenwidth()
    screen_height = app.winfo_screenheight()
    x = (screen_width // 2) - (600 // 2)
    y = (screen_height // 2) - (400 // 2)
    info_window.geometry(f"600x400+{x}+{y}")

    ctk.CTkLabel(info_window, text="User Information", font=("Helvetica", 16, "bold"), anchor="center").pack(pady=(10, 5))

    tree_frame = ctk.CTkFrame(info_window)
    tree_frame.pack(pady=5, padx=8, fill="both", expand=True)

    scrollbar = ttk.Scrollbar(tree_frame, orient="vertical")
    scrollbar.pack(side="right", fill="y")

    tree = ttk.Treeview(tree_frame, columns=("Attribute", "Value"), show="headings", yscrollcommand=scrollbar.set)
    tree.pack(fill="both", expand=True)

    scrollbar.config(command=tree.yview)

    tree.heading("Attribute", text=" ", anchor="center")
    tree.heading("Value", text="Information", anchor="center")

    tree.column("Attribute", anchor="w", width=200)
    tree.column("Value", anchor="w", width=400)

    #this is for inserting the data to the treeview
    for label, value in data:
        tree.insert("", "end", values=(label, value))

    style = ttk.Style()
    style.theme_use("clam")
    style.configure("Treeview", font=("Century Gothic", 12), rowheight=25)
    style.configure("Treeview.Heading", font=("Century Gothic", 12, "bold"), foreground="black")
    style.map("Treeview.Heading", background=[("active", "#FFDAB9")], foreground=[("active", "black")])
    style.configure("Treeview.Heading", background="#FFDAB9")  # Pastel orange for headings

    def infoback(info_window):
        info_window.destroy()
        dashboard.deiconify()

    ctk.CTkButton(info_window, text="Go Back", command=lambda: infoback(info_window), fg_color="#FFDAB9", text_color="black").pack(pady=20)

def equipmentNames(): #This is to fetch all the equipment and their status that is added to the database called Equipments
    try:
        conn = databasejoin()
        cursor = conn.cursor()
        cursor.execute("SELECT Equipment_ID, Equipment_Name, Status FROM Equipments")
        equipment_data = cursor.fetchall()
        conn.close()
        return equipment_data
    except Exception as e:
        messagebox.showerror("Database Error", f"Error fetching equipment data: {e}")
        return []

def ExerciseLogWindow(user_id): #This function is to log and view their exercises
    global dashboard
    dashboard.withdraw()
    global equipment_menu, set_entry, reps_entry, log_window
    
    log_window = ctk.CTkToplevel(app)
    log_window.resizable(False, False)
    log_window.geometry("600x700")
    log_window.title("Exercise Log")

    screen_width = app.winfo_screenwidth()
    screen_height = app.winfo_screenheight()
    x = (screen_width // 2) - (600 // 2)
    y = (screen_height // 2) - (700 // 2)
    log_window.geometry(f"600x700+{x}+{y}")

    ctk.CTkLabel(log_window, text="Log Your Exercise", font=("Century Gothic", 18), text_color="white").pack(pady=10)

    try:
        conn = databasejoin()
        cursor = conn.cursor()

        cursor.execute("SELECT Status FROM Users WHERE User_ID = %s", (user_id,))
        account_status = cursor.fetchone()

        if account_status and account_status[0] in ['Expired', 'Suspended']:
            messagebox.showerror("Account Inactive", "Your account is either expired or suspended. You cannot log exercises.")
            conn.close()
            log_window.destroy()
            dashboard.deiconify()
            return

        conn.close()

    except Exception as e:
        messagebox.showerror("Database Error", f"Error checking account status: {e}")
        log_window.destroy()
        dashboard.deiconify()
        return

    ctk.CTkLabel(log_window, text="Select Equipment:", text_color="white").pack(pady=(10, 0))

    equipment_data = equipmentNames()
    if not equipment_data:
        messagebox.showerror("Error", "No equipment data found in the system.")
        return

    available_equipment = [name for _, name, status in equipment_data if status == "Available"]
    equipment_status = {name: status for _, name, status in equipment_data}

    if not available_equipment:
        messagebox.showerror("Error", "No equipment is currently available.")
        return

    #This is the function for the drop down menu
    equipment_menu = ctk.CTkOptionMenu(log_window, values=available_equipment, fg_color="#FFDAB9", button_color="#FFDAB9", text_color="black")
    equipment_menu.pack(pady=5)

    set_entry = ctk.CTkEntry(log_window, placeholder_text="Sets", width=200)
    set_entry.pack(pady=5)
    reps_entry = ctk.CTkEntry(log_window, placeholder_text="Reps", width=200)
    reps_entry.pack(pady=5)

    def log_exercise():
        equipment_name = equipment_menu.get()
        sets = set_entry.get()
        reps = reps_entry.get()

        if not equipment_name or not sets or not reps:
            messagebox.showerror("Input Error", "Please fill in all fields.")
            return

        if not sets.isdigit() or not reps.isdigit():
            messagebox.showerror("Input Error", "Sets and Reps must be numeric.")
            return

        # Check the equipment status
        if equipment_status[equipment_name] != "Available":
            messagebox.showerror(
                "Unavailable Equipment", f"The selected equipment '{equipment_name}' is currently {equipment_status[equipment_name]}.")
            return

        try:
            conn = databasejoin()
            cursor = conn.cursor()

            cursor.execute("SELECT Equipment_ID FROM Equipments WHERE Equipment_Name = %s", (equipment_name,))
            result = cursor.fetchone()
            if not result:
                messagebox.showerror("Error", f"Equipment '{equipment_name}' not found.")
                return

            equipment_id = result[0]

            cursor.execute(""" INSERT INTO Exercise_Log (User_ID, Equipment_ID, Equipment_Name, Sets, Reps, log_date) VALUES (%s, %s, %s, %s, %s, NOW()) """, (user_id, equipment_id, equipment_name, int(sets), int(reps)))
            conn.commit()
            conn.close()

            messagebox.showinfo("Success", "Exercise logged successfully!")
            set_entry.delete(0, tk.END)
            reps_entry.delete(0, tk.END)
            load_logged_exercises()

        except Exception as e:
            messagebox.showerror("Database Error", f"Error logging exercise: {e}")

    ctk.CTkButton(log_window, text="Log Workout", command=log_exercise, fg_color="#FFDAB9", text_color="black").pack(pady=10)

    ctk.CTkLabel(log_window, text="Your Logged Exercises", font=("Century Gothic", 16), text_color="white").pack(pady=10)

    columns = ("log_date", "equipment_name", "sets", "reps")
    exercise_tree_frame = ctk.CTkFrame(log_window)
    exercise_tree_frame.pack(pady=2, padx=10, fill="both", expand=True)

    exercise_tree = ttk.Treeview(exercise_tree_frame, columns=columns, show="headings", height=10)
    exercise_tree.heading("log_date", text="Log Date")
    exercise_tree.heading("equipment_name", text="Equipment Name")
    exercise_tree.heading("sets", text="Sets")
    exercise_tree.heading("reps", text="Reps")

    exercise_tree.column("log_date", width=150, anchor="center")
    exercise_tree.column("equipment_name", width=150, anchor="center")
    exercise_tree.column("sets", width=100, anchor="center")
    exercise_tree.column("reps", width=100, anchor="center")

    style = ttk.Style()
    style.theme_use("clam")
    style.configure("Treeview", font=("Century Gothic", 12), rowheight=25)
    style.configure("Treeview.Heading", font=("Century Gothic", 12, "bold"), foreground="black")
    style.map("Treeview.Heading", background=[("active", "#FFDAB9")], foreground=[("active", "black")])
    style.configure("Treeview.Heading", background="#FFDAB9")  # Pastel orange for headings

    scrollbar = ttk.Scrollbar(exercise_tree_frame, orient="vertical", command=exercise_tree.yview)
    exercise_tree.config(yscrollcommand=scrollbar.set)
    scrollbar.grid(row=0, column=1, sticky="ns")
    exercise_tree.grid(row=0, column=0, sticky="nsew")

    exercise_tree_frame.grid_rowconfigure(0, weight=1)
    exercise_tree_frame.grid_columnconfigure(0, weight=1)

    def load_logged_exercises():
        for row in exercise_tree.get_children():
            exercise_tree.delete(row)

        try:
            conn = databasejoin()
            cursor = conn.cursor()
            cursor.execute(""" 
                SELECT log_date, Equipment_Name, Sets, Reps
                FROM Exercise_Log
                WHERE User_ID = %s
                ORDER BY log_date DESC
            """, (user_id,))
            logged_exercises = cursor.fetchall()
            conn.close()

            for exercise in logged_exercises:
                exercise_tree.insert("", "end", values=exercise)

        except Exception as e:
            messagebox.showerror("Database Error", f"Error fetching logged exercises: {e}")

    load_logged_exercises()

    def back_to_dashboard():
        log_window.destroy()
        dashboard.deiconify()

    ctk.CTkButton(log_window, text="Go Back", command=back_to_dashboard, fg_color="#FFDAB9", text_color="black").pack(pady=10)
#-----------------------------LOGIN---------------------------------#
def UserLogin(): # This is the login function gets the username and password of the user to enter the User Dashboard
    username = usern.get() 
    password = passw.get()

    if not username or not password:
        messagebox.showerror("Input Error", "Please enter both username and password.")
        return

    try:
        conn = databasejoin()
        cursor = conn.cursor()

        cursor.execute(""" SELECT User_ID FROM Users WHERE BINARY User_Name = %s AND BINARY Pass_word = %s """, (username, password))
        user = cursor.fetchone()
        conn.close()

        if user:
            messagebox.showinfo("Login Success", "Welcome!")
            app.withdraw()
            UserDashboard(user[0])
        else:
            messagebox.showerror("Login Error", "Invalid username or password.")
    except Exception as e:
        messagebox.showerror("Database Error", f"Error logging in: {e}")
#--------------------------FUNCTION FOR REGISTERING--------------------------#
def regwindow():# This function is for the user to register their accounts
    def userreg():
        firstname = firstname_entry.get()
        lastname = lastname_entry.get()
        username = username_entry.get()
        password = password_entry.get()
        password1 = password1_entry.get()
        age = age_entry.get()
        email = email_entry.get()
        address = address_entry.get()
        phone = phone_entry.get()
        trainer_selection = trainer_menu.get()
        membership_selection = membership_menu.get()

        if not all([firstname, lastname, username, password, password1, age, email, address, phone]):
            messagebox.showerror("Input Error", "Please fill in all fields.")
            return

        if password != password1:
            messagebox.showerror("Password Error", "Passwords do not match.")
            return

        try:
            age = int(age)
        except ValueError:
            messagebox.showerror("Input Error", "Please enter a valid age.")
            return

        trainer_id = None
        if trainer_selection != "No Trainers Available":
            trainer_id = int(trainer_selection.split(" - ")[0])  # Extract Trainer_ID from selection

        if not memberships:
            messagebox.showerror("Membership Error", "No memberships available. Please contact support.")
            return

        membership_data = next(
            (m for m in memberships if f"{m[1]} ({format_duration(m[2])}, ₱{m[3]:,.2f})" == membership_selection), None
        )

        if membership_data:
            membership_id, _, membership_duration, membership_price = membership_data
        else:
            messagebox.showerror("Membership Error", "Please select a valid membership.")
            return

        try:
            conn = databasejoin()
            cursor = conn.cursor()

            cursor.execute("SELECT * FROM Users WHERE User_Name = %s", (username,))
            if cursor.fetchone():
                messagebox.showerror("Username Error", "Username already exists.")
                conn.close()
                return

            cursor.execute(""" INSERT INTO Users (First_Name, Last_Name, User_Name, Pass_word, Age, Email, Address, Phone, Trainer_ID, Membership_ID) VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s) """, (firstname, lastname, username, password, age, email, address, phone, trainer_id, membership_id))
            conn.commit()

            user_id = cursor.lastrowid

            membership_start_date = datetime.date.today()
            cursor.execute(""" INSERT INTO User_Memberships (User_ID, Membership_ID, Membership_Start_Date, Membership_Duration, Status) VALUES (%s, %s, %s, %s, 'Active') """, (user_id, membership_id, membership_start_date, membership_duration))
            conn.commit()

            conn.close()

            messagebox.showinfo("Registration Success", "You have successfully registered!")
            windowreg.destroy()

        except Exception as e:
            messagebox.showerror("Database Error", f"Error during registration: {e}")

    #This is the main window of the register

    windowreg = ctk.CTkToplevel(app)
    windowreg.geometry("500x650")
    windowreg.resizable(False, False)
    windowreg.title("Register: Time4Fitness")

    screen_width = windowreg.winfo_screenwidth()
    screen_height = windowreg.winfo_screenheight()
    x = (screen_width // 2) - (500 // 2)
    y = (screen_height // 2) - (650 // 2)
    windowreg.geometry(f"500x650+{x}+{y}")

    backimg = tk.PhotoImage(file="assets/REGISTER.png")
    windowreg.backimg = backimg
    backlabel = tk.Label(windowreg, image=backimg)
    backlabel.place(relwidth=1, relheight=1)

    firstname_entry = ctk.CTkEntry(windowreg, placeholder_text="First Name", width=300)
    firstname_entry.pack(pady=(115, 5))
    lastname_entry = ctk.CTkEntry(windowreg, placeholder_text="Last Name", width=300)
    lastname_entry.pack(pady=5)
    username_entry = ctk.CTkEntry(windowreg, placeholder_text="Username", width=300)
    username_entry.pack(pady=5)
    password_entry = ctk.CTkEntry(windowreg, placeholder_text="Password", show="*", width=300)
    password_entry.pack(pady=5)
    password1_entry = ctk.CTkEntry(windowreg, placeholder_text="Re-enter Password", show="*", width=300)
    password1_entry.pack(pady=5)
    age_entry = ctk.CTkEntry(windowreg, placeholder_text="Age", width=300)
    age_entry.pack(pady=5)
    email_entry = ctk.CTkEntry(windowreg, placeholder_text="Email Address", width=300)
    email_entry.pack(pady=5)
    address_entry = ctk.CTkEntry(windowreg, placeholder_text="Address", width=300)
    address_entry.pack(pady=5)
    phone_entry = ctk.CTkEntry(windowreg, placeholder_text="Phone Number", width=300)
    phone_entry.pack(pady=5)

    try:
        conn = databasejoin()
        cursor = conn.cursor()

        cursor.execute("SELECT Trainer_ID, Trainer_Name, Trainer_Specialization FROM Trainers")
        trainers = cursor.fetchall()
        trainer_menu_values = [f"{trainer_id} - {name} - {specialization}" for trainer_id, name, specialization in trainers]

        cursor.execute("SELECT Membership_ID, Membership_Type, Membership_Duration, Membership_Cost FROM Memberships WHERE Status = 'Active'")
        memberships = cursor.fetchall()

        def format_duration(days):
            if days == 1:  
                return "1 Day"
            elif days == 30:
                return "1 Month"
            elif days == 90:
                return "3 Months"
            elif days == 180:
                return "6 Months"
            else:
                months = days // 30
                return f"{months} Month{'s' if months > 1 else ''}"

        membership_menu_values = [
            f"{membership_type} ({format_duration(duration)}, ₱{cost:,.2f})"
            for _, membership_type, duration, cost in memberships
        ]
        conn.close()
    except Exception as e:
        messagebox.showerror("Database Error", f"Error fetching memberships: {e}")
        memberships = []

    trainer_menu = ctk.CTkOptionMenu(
        windowreg,
        values=trainer_menu_values if trainer_menu_values else ["No Trainers Available"],
        width=300,
        text_color="Black",
        fg_color="white",
    )
    trainer_menu.pack(pady=5)
    trainer_menu.set("Select Trainer")

    membership_menu = ctk.CTkOptionMenu(
        windowreg,
        values=membership_menu_values if membership_menu_values else ["No Memberships Available"],
        width=300,
        text_color="Black",
        fg_color="white",
    )
    membership_menu.pack(pady=5)
    membership_menu.set("Select Membership Plan")

    register_button = ctk.CTkButton(
        windowreg, text="Register", text_color="Black", fg_color="white", command=userreg)
    register_button.pack(pady=20)

    trainer_menu.lift()
    membership_menu.lift()
    register_button.lift()
#-------------------------------ADMIN DASHBOARD ------------------------------#
def admin_UserLogin():  # This function is exclusive for admins only
    admin_win = ctk.CTkToplevel(app)
    admin_win.resizable(False, False)
    admin_win.geometry("800x700")
    admin_win.title("Admin Dashboard")

    screen_width = admin_win.winfo_screenwidth()
    screen_height = admin_win.winfo_screenheight()
    x = (screen_width // 2) - (800 // 2)
    y = (screen_height // 2) - (700 // 2)
    admin_win.geometry(f"800x700+{x}+{y}")

    ctk.CTkLabel(admin_win, text="Admin Dashboard", font=("Century Gothic", 20,)).pack(pady=20)

    # Create a frame for displaying statistics
    stats_frame = ctk.CTkFrame(admin_win)
    stats_frame.pack(pady=20, padx=20, fill="x")

    # Create a frame to hold the labels in one row
    row_frame = ctk.CTkFrame(stats_frame)
    row_frame.pack(side="top", pady=20, anchor="center")

    # Create labels for statistics and pack them in the row_frame
    active_label = ctk.CTkLabel(
        row_frame, 
        text="Active Users: 0", 
        font=("Century Gothic", 14, "bold"),  # Bold font
        text_color="#FFB347"  # Pastel orange color
    )
    active_label.pack(side="left", padx=20)

    suspended_label = ctk.CTkLabel(
        row_frame, 
        text="Suspended/Expired Users: 0", 
        font=("Century Gothic", 14, "bold"),  # Bold font
        text_color="#FFB347"  # Pastel orange color
    )
    suspended_label.pack(side="left", padx=20)

    sales_label = ctk.CTkLabel(
        row_frame, 
        text="Total Sales: ₱0.00", 
        font=("Century Gothic", 14, "bold"),  # Bold font
        text_color="#FFB347"  # Pastel orange color
    )
    sales_label.pack(side="left", padx=20)


    # Function to load statistics (active users, suspended/expired, total sales)
    def load_stats():
        try:
            conn = databasejoin()
            cursor = conn.cursor()

            # Query active users from the 'usersbymembership' view
            cursor.execute("""
                SELECT COUNT(*) 
                FROM usersbymembership 
                WHERE status = 'Active'
            """)
            result = cursor.fetchone()
            active_users = result[0] if result and result[0] is not None else 0

            # Query suspended/expired users from the 'usersbymembership' view
            cursor.execute("""
                SELECT COUNT(*) 
                FROM usersbymembership 
                WHERE status IN ('Suspended', 'Expired')
            """)
            result = cursor.fetchone()
            suspended_users = result[0] if result and result[0] is not None else 0

            # Query total sales from the 'totalsalesbyyear' view
            cursor.execute("""
                SELECT SUM(Total_Sales) 
                FROM totalsalesbyyear
            """)
            result = cursor.fetchone()
            total_sales = result[0] if result and result[0] is not None else 0.00

            conn.close()

            # Manual formatting of the total sales as currency
            formatted_sales = "₱{:,.2f}".format(total_sales)

            # Update the label with the fetched data
            active_label.configure(text=f"Active Users: {active_users}")
            suspended_label.configure(text=f"Suspended/Expired Users: {suspended_users}")
            sales_label.configure(text=f"Total Sales: {formatted_sales}")

        except Exception as e:
            messagebox.showerror("Database Error", f"Error loading statistics: {e}")

    load_stats()

    style = ttk.Style()
    style.theme_use("clam")
    style.configure("Treeview", font=("Century Gothic", 12), rowheight=25)
    style.configure("Treeview.Heading", font=("Century Gothic", 12, "bold"), foreground="black")

    style.map("Treeview.Heading",
              background=[("active", "#F4A460")], foreground=[("active", "black")])

    style.layout("Treeview.Heading", [
        ('Treeheading.cell', {'sticky': 'nswe'}),
        ('Treeheading.border', {'sticky': 'nswe', 'children': [
            ('Treeheading.padding', {'sticky': 'nswe', 'children': [
                ('Treeheading.image', {'side': 'right', 'sticky': ''}),
                ('Treeheading.text', {'sticky': 'we'})
            ]})
        ]})
    ])
    style.configure("Treeview.Heading", background="#FFDAB9")

    # Frame for Treeview and Scrollbars
    tree_frame = ctk.CTkFrame(admin_win)
    tree_frame.pack(pady=10, padx=10, fill="both", expand=True)

    # Define Treeview Columns
    columns = ("user_id", "first_name", "last_name", "membership_type", "membership_cost", "status")
    user_tree = ttk.Treeview(tree_frame, columns=columns, show="headings", height=5)

    # Configure Treeview Headings
    user_tree.heading("user_id", text="User ID")
    user_tree.heading("first_name", text="First Name")
    user_tree.heading("last_name", text="Last Name")
    user_tree.heading("membership_type", text="Membership Type")
    user_tree.heading("membership_cost", text="Cost")
    user_tree.heading("status", text="Status")

    # Configure Treeview Columns
    user_tree.column("user_id", width=70, anchor="center")
    user_tree.column("first_name", width=150, anchor="center")
    user_tree.column("last_name", width=150, anchor="center")
    user_tree.column("membership_type", width=200, anchor="center")
    user_tree.column("membership_cost", width=120, anchor="center")
    user_tree.column("status", width=120, anchor="center")

    # Scrollbars
    v_scrollbar = ttk.Scrollbar(tree_frame, orient="vertical", command=user_tree.yview)
    h_scrollbar = ttk.Scrollbar(tree_frame, orient="horizontal", command=user_tree.xview)
    user_tree.configure(yscrollcommand=v_scrollbar.set, xscrollcommand=h_scrollbar.set)

    # Layout Treeview and Scrollbars with grid
    tree_frame.grid_columnconfigure(0, weight=1)
    tree_frame.grid_rowconfigure(0, weight=1)

    user_tree.grid(row=0, column=0, sticky="nsew")
    v_scrollbar.grid(row=0, column=1, sticky="ns")
    h_scrollbar.grid(row=1, column=0, sticky="ew")

    def load_users():
        """Load active users into the Treeview."""
        for row in user_tree.get_children():
            user_tree.delete(row)

        try:
            conn = databasejoin()
            cursor = conn.cursor()

            cursor.execute("""
                SELECT u.User_ID, u.First_Name, u.Last_Name, m.Membership_Type, m.Membership_Cost, u.Status 
                FROM Users u
                LEFT JOIN Memberships m ON u.Membership_ID = m.Membership_ID
            """)
            users = cursor.fetchall()
            conn.close()

            for user in users:
                user_tree.insert("", "end", values=user)

        except Exception as e:
            messagebox.showerror("Database Error", f"Error loading users: {e}")

    def approve_payment():
        """Approve the user's pending payment."""
        selected_item = user_tree.selection()
        if not selected_item:
            messagebox.showwarning("Selection Error", "Please select a user to approve payment.")
            return

        user_id = user_tree.item(selected_item[0], "values")[0]
        try:
            conn = databasejoin()
            cursor = conn.cursor()

            # Check if there is a pending payment for this user
            cursor.execute("""
                SELECT Payment_ID 
                FROM Payments 
                WHERE User_ID = %s AND Status = 'Pending'
            """, (user_id,))
            pending_payment = cursor.fetchone()  # Fetch one result immediately

            # Clear any additional rows from the result set
            cursor.fetchall()  # Ensures the result set is fully consumed

            if not pending_payment:
                messagebox.showerror("Payment Error", "No pending payment found for this user.")
                conn.close()
                return

            # Approve the pending payment
            cursor.execute("""
                UPDATE Payments
                SET Status = 'Approved'
                WHERE Payment_ID = %s
            """, (pending_payment[0],))  # Use the fetched Payment_ID
            conn.commit()

            conn.close()
            messagebox.showinfo("Success", "Payment approved!")
            load_users()
        except Exception as e:
            messagebox.showerror("Database Error", f"Error approving payment: {e}")

    def update_status():
        """Update the status of the selected user."""
        selected_item = user_tree.selection()
        if not selected_item:
            messagebox.showwarning("Selection Error", "Please select a user to update status.")
            return

        user_id = user_tree.item(selected_item[0], "values")[0]
        new_status = status_menu.get()

        try:
            conn = databasejoin()
            cursor = conn.cursor()
            cursor.execute("""
                UPDATE Users
                SET Status = %s
                WHERE User_ID = %s
            """, (new_status, user_id))
            conn.commit()
            conn.close()
            messagebox.showinfo("Success", f"User status updated to {new_status}!")
            load_users()
        except Exception as e:
            messagebox.showerror("Database Error", f"Error updating status: {e}")

    def delete_user():

        """Delete a selected user and archive them in the Deleted_Users table."""
        selected_item = user_tree.selection()
        if not selected_item:
            messagebox.showwarning("Selection Error", "Please select a user to delete.")
            return

        user_id = user_tree.item(selected_item[0], "values")[0]  # Get the User_ID from the selected row

        # Confirm deletion with the user
        confirm = messagebox.askyesno("Confirm Deletion", "Are you sure you want to delete this user?")
        if not confirm:
            return  # If user presses No, exit the function

        try:
            conn = databasejoin()
            cursor = conn.cursor()

            # Fetch user data before deleting
            cursor.execute("""
                SELECT User_ID, First_Name, Last_Name, User_Name, Pass_word, Age, Email, Address, Phone, Trainer_ID, Membership_ID
                FROM Users
                WHERE User_ID = %s
            """, (user_id,))
            user_data = cursor.fetchone()

            if not user_data:
                messagebox.showerror("Error", "User not found in the database.")
                return

            # Insert user data into Deleted_Users
            cursor.execute("""
                INSERT INTO Deleted_Users 
                (User_ID, First_Name, Last_Name, User_Name, Pass_word, Age, Email, Address, Phone, Trainer_ID, Membership_ID, Deletion_Date)
                VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, NOW())
            """, user_data)

            # Delete dependent records from related tables
            cursor.execute("DELETE FROM Payments WHERE User_ID = %s", (user_id,))
            cursor.execute("DELETE FROM Attendance WHERE User_ID = %s", (user_id,))
            cursor.execute("DELETE FROM User_Memberships WHERE User_ID = %s", (user_id,))

            # Remove the user from the Users table
            cursor.execute("DELETE FROM Users WHERE User_ID = %s", (user_id,))
            conn.commit()
            conn.close()

            messagebox.showinfo("Success", "User deleted and archived.")
            load_users()  # Refresh the user list

        except Exception as e:
            messagebox.showerror("Database Error", f"Error deleting user: {e}")
  
    def view_user_info():
            """View detailed information about a selected user."""
            selected_item = user_tree.selection()
            if not selected_item:
                messagebox.showwarning("Selection Error", "Please select a user to view their information.")
                return

            user_id = user_tree.item(selected_item[0], "values")[0]
            try:
                conn = databasejoin()
                cursor = conn.cursor()
                cursor.execute("""
                    SELECT u.First_Name, u.Last_Name, u.Email, u.Phone, u.Address, m.Membership_Type, m.Membership_Cost
                    FROM Users u
                    LEFT JOIN Memberships m ON u.Membership_ID = m.Membership_ID
                    WHERE u.User_ID = %s
                """, (user_id,))
                user_info = cursor.fetchone()
                conn.close()

                if not user_info:
                    messagebox.showerror("Data Error", "No information found for this user.")
                    return

                # Combine first and last name
                full_name = f"{user_info[0]} {user_info[1]}"  # Combine First_Name and Last_Name

                # Create a new window to display the information
                info_win = ctk.CTkToplevel(admin_win)
                info_win.resizable(False, False)
                info_win.geometry("500x350")
                info_win.title("User Information")

                # Center the window
                screen_width = info_win.winfo_screenwidth()
                screen_height = info_win.winfo_screenheight()
                x = (screen_width // 2) - (500 // 2)
                y = (screen_height // 2) - (350 // 2)
                info_win.geometry(f"500x350+{x}+{y}")

                # Create Treeview widget
                tree = ttk.Treeview(info_win, columns=("Field", "Value"), show="headings", height=8)
                tree.heading("Field", text=" ", anchor="center")
                tree.heading("Value", text="Information", anchor="center")
                tree.column("Field", width=200, anchor="w")
                tree.column("Value", width=280, anchor="w")
                tree.pack(pady=10, padx=10, fill="both", expand=True)

                # Add combined full name and other data to the Treeview
                labels = ["Full Name", "Email", "Phone", "Address", "Membership Type", "Membership Cost"]
                values = [full_name, user_info[2], user_info[3], user_info[4], user_info[5], user_info[6]]
                for label, value in zip(labels, values):
                    tree.insert("", "end", values=(label, value))

            except Exception as e:
                messagebox.showerror("Database Error", f"Error fetching user information: {e}")

    def view_deleted_users():
        """Open a window to view deleted users."""
        deleted_users_win = ctk.CTkToplevel(admin_win)
        deleted_users_win.resizable(False,False)
        deleted_users_win.geometry("1000x400")
        deleted_users_win.title("Deleted Users")

        screen_width = deleted_users_win.winfo_screenwidth()    #This line is to center the window
        screen_height = deleted_users_win.winfo_screenheight()
        x = (screen_width // 2) - (1000 // 2)
        y = (screen_height // 2) - (400 // 2)
        deleted_users_win.geometry(f"1000x400+{x}+{y}")

        columns = ("user_id", "first_name", "last_name", "user_name", "email", "pass_word", "deletion_date")
        deleted_tree = ttk.Treeview(deleted_users_win, columns=columns, show="headings")

        # Define headings
        deleted_tree.heading("user_id", text="User ID")
        deleted_tree.heading("first_name", text="First Name")
        deleted_tree.heading("last_name", text="Last Name")
        deleted_tree.heading("user_name", text="Username")
        deleted_tree.heading("email", text="Email")
        deleted_tree.heading("pass_word", text="Password")
        deleted_tree.heading("deletion_date", text="Deletion Date")

        # Define column widths
        deleted_tree.column("user_id", width=70, anchor="center")
        deleted_tree.column("first_name", width=120, anchor="center")
        deleted_tree.column("last_name", width=120, anchor="center")
        deleted_tree.column("user_name", width=120, anchor="center")
        deleted_tree.column("email", width=180, anchor="center")
        deleted_tree.column("pass_word", width=180, anchor="center")
        deleted_tree.column("deletion_date", width=150, anchor="center")

        deleted_tree.pack(fill="both", expand=True)

        try:
            conn = databasejoin()
            cursor = conn.cursor()

            # Fetch deleted user details
            cursor.execute("""
                SELECT User_ID, First_Name, Last_Name, User_Name, Email, Pass_word, Deletion_Date 
                FROM Deleted_Users
            """)
            deleted_users = cursor.fetchall()
            conn.close()

            # Insert deleted user data into the Treeview
            for user in deleted_users:
                deleted_tree.insert("", "end", values=user)

        except Exception as e:
            messagebox.showerror("Database Error", f"Error fetching deleted users: {e}")

    def manage_equipment():
            """Open a window to manage equipment."""
            equip_win = ctk.CTkToplevel(admin_win)
            equip_win.resizable(False,False)
            equip_win.geometry("700x400")
            equip_win.title("Manage Equipment")

            screen_width = equip_win.winfo_screenwidth()    #This line is to center the window
            screen_height = equip_win.winfo_screenheight()
            x = (screen_width // 2) - (600 // 2)
            y = (screen_height // 2) - (500 // 2)
            equip_win.geometry(f"600x500+{x}+{y}")
            # Frame for Treeview
            equip_frame = ctk.CTkFrame(equip_win)
            equip_frame.pack(pady=10, fill="both", expand=True)

            # Define columns
            columns = ("equipment_id", "equipment_name", "equipment_type", "status")
            equip_tree = ttk.Treeview(equip_frame, columns=columns, show="headings")

            # Define headings
            equip_tree.heading("equipment_id", text="Equipment ID")
            equip_tree.heading("equipment_name", text="Name")
            equip_tree.heading("equipment_type", text="Type")
            equip_tree.heading("status", text="Status")

            # Define column widths
            equip_tree.column("equipment_id", width=100, anchor="center")
            equip_tree.column("equipment_name", width=200, anchor="center")
            equip_tree.column("equipment_type", width=150, anchor="center")
            equip_tree.column("status", width=150, anchor="center")

            equip_tree.pack(fill="both", expand=True)

            def load_equipment():
                """Load equipment details into the Treeview."""
                for row in equip_tree.get_children():
                    equip_tree.delete(row)
                try:
                    conn = databasejoin()
                    cursor = conn.cursor()
                    cursor.execute("SELECT Equipment_ID, Equipment_Name, Equipment_Type, Status FROM Equipments")
                    equipment = cursor.fetchall()
                    conn.close()
                    for equip in equipment:
                        equip_tree.insert("", "end", values=equip)
                except Exception as e:
                    messagebox.showerror("Database Error", f"Error loading equipment: {e}")

            def update_equipment_status():
                """Update the status of selected equipment."""
                selected_item = equip_tree.selection()
                if not selected_item:
                    messagebox.showwarning("Selection Error", "Please select equipment to update its status.")
                    return

                equipment_id = equip_tree.item(selected_item[0], "values")[0]
                new_status = status_menu.get()

                try:
                    conn = databasejoin()
                    cursor = conn.cursor()
                    cursor.execute("""
                        UPDATE Equipments
                        SET Status = %s
                        WHERE Equipment_ID = %s
                    """, (new_status, equipment_id))
                    conn.commit()
                    conn.close()
                    messagebox.showinfo("Success", f"Equipment status updated to {new_status}!")
                    load_equipment()
                except Exception as e:
                    messagebox.showerror("Database Error", f"Error updating equipment status: {e}")

            # Dropdown for equipment status
            status_menu = ttk.Combobox(equip_win, values=["Available", "In Maintenance", "Out of Order"], state="readonly")
            status_menu.pack(pady=5)

            pastel_orange = "#FAD4B7"

            ctk.CTkButton( equip_win,text="Update Equipment Status", command=update_equipment_status, fg_color=pastel_orange, text_color="black" ).pack(pady=5)

            load_equipment()

    def renew_membership():
        selected_item = user_tree.selection()
        if not selected_item:
            messagebox.showwarning("Selection Error", "Please select a user to renew their membership.")
            return

        user_id = user_tree.item(selected_item[0], "values")[0]

        try:
            conn = databasejoin()
            cursor = conn.cursor()

            # Fetch available memberships
            cursor.execute("SELECT Membership_ID, Membership_Type, Membership_Cost FROM Memberships")
            membership_plans = cursor.fetchall()

            if not membership_plans:
                messagebox.showerror("Error", "No membership plans found.")
                conn.close()
                return

            # Show selection dialog
            renew_win = ctk.CTkToplevel(admin_win)
            renew_win.geometry("400x250")
            renew_win.title("Renew Membership")

            ctk.CTkLabel(renew_win, text="Select New Membership Plan", font=("Century Gothic", 16)).pack(pady=10)
            membership_menu = ttk.Combobox(
                renew_win,
                values=[f"{plan[1]} (ID: {plan[0]}, ₱{plan[2]:,.2f})" for plan in membership_plans],
                state="readonly",
            )
            membership_menu.pack(pady=10)
            membership_menu.current(0)

            def confirm_renewal():
                selected_plan = membership_menu.get()
                new_membership_id = int(selected_plan.split("ID: ")[1].split(",")[0])
                try:
                    # Update membership
                    cursor.execute("""
                        UPDATE Users
                        SET Membership_ID = %s
                        WHERE User_ID = %s
                    """, (new_membership_id, user_id))

                    # Log payment
                    cursor.execute("""
                        SELECT Membership_Type, Membership_Cost
                        FROM Memberships
                        WHERE Membership_ID = %s
                    """, (new_membership_id,))
                    membership_info = cursor.fetchone()

                    if membership_info:
                        membership_type, membership_cost = membership_info
                        cursor.execute("""
                            INSERT INTO Payments (User_ID, Membership_ID, Membership_Type, Payment_Date, Amount, Status)
                            VALUES (%s, %s, %s, NOW(), %s, 'Pending')
                        """, (user_id, new_membership_id, membership_type, membership_cost))
                        conn.commit()
                        messagebox.showinfo("Success", "Membership renewed. Payment set to 'Pending'.")
                        renew_win.destroy()
                        load_users()
                    else:
                        messagebox.showerror("Error", "Failed to fetch membership details.")
                except Exception as e:
                    messagebox.showerror("Database Error", f"Error renewing membership: {e}")
                finally:
                    conn.close()

            ctk.CTkButton(renew_win, text="Confirm Renewal", command=confirm_renewal).pack(pady=20)
        except Exception as e:
            messagebox.showerror("Database Error", f"Error fetching membership plans: {e}")

    def BacktoMain():
            """Log out the admin and return to the main application."""
            if admin_win:
                admin_win.destroy()  # Close the admin window
                messagebox.showinfo("Logout", "You have been logged out.")  # Inform the admin about the logout
            app.deiconify()  # Show the main application window
            Loginclearinput()  # Clear any existing input for login

    def edit_user_info():
        selected_item = user_tree.selection()
        if not selected_item:
            messagebox.showwarning("Selection Error", "Please select a user to edit their information.")
            return

        user_id = user_tree.item(selected_item[0], "values")[0]  # Get the selected user's ID

        try:
            conn = databasejoin()
            cursor = conn.cursor()

            # Fetch the current details of the user
            cursor.execute("""
                SELECT First_Name, Last_Name, Email, Phone, Address 
                FROM Users 
                WHERE User_ID = %s
            """, (user_id,))
            user_info = cursor.fetchone()
            conn.close()

            if not user_info:
                messagebox.showerror("Data Error", "No information found for this user.")
                return

            # Create a new window for editing
            edit_win = ctk.CTkToplevel(admin_win)
            edit_win.geometry("400x500")
            edit_win.resizable(False,False)
            edit_win.title("Edit User Information")

            screen_width = edit_win.winfo_screenwidth()
            screen_height = edit_win.winfo_screenheight()
            x = (screen_width // 2) - (400 // 2)
            y = (screen_height // 2) - (500 // 2)
            edit_win.geometry(f"400x500+{x}+{y}")

            ctk.CTkLabel(edit_win, text="Edit User Information", font=("Century Gothic", 16, "bold")).pack(pady=10)

            # Entry fields for user information
            labels = ["First Name", "Last Name", "Email", "Phone", "Address"]
            fields = [ctk.CTkEntry(edit_win, width=300) for _ in labels]
            values = list(user_info)

            for label, field, value in zip(labels, fields, values):
                ctk.CTkLabel(edit_win, text=label, font=("Century Gothic", 14)).pack(pady=5)
                field.insert(0, value)
                field.pack(pady=5)

            def save_changes():
                """Save the edited information to the database."""
                updated_values = [field.get().strip() for field in fields]
                if not all(updated_values):
                    messagebox.showerror("Input Error", "All fields must be filled.")
                    return

                try:
                    conn = databasejoin()
                    cursor = conn.cursor()
                    cursor.execute("""
                        UPDATE Users 
                        SET First_Name = %s, Last_Name = %s, Email = %s, Phone = %s, Address = %s 
                        WHERE User_ID = %s
                    """, (*updated_values, user_id))
                    conn.commit()
                    conn.close()

                    messagebox.showinfo("Success", "User information updated successfully!")
                    edit_win.destroy()
                    load_users()  # Refresh the user list
                except Exception as e:
                    messagebox.showerror("Database Error", f"Error updating user information: {e}")

            ctk.CTkButton(edit_win, text="Save Changes", command=save_changes, fg_color="#FAD4B7", text_color="black").pack(pady=20)

        except Exception as e:
            messagebox.showerror("Database Error", f"Error fetching user information: {e}")

    status_menu = ttk.Combobox(admin_win, values=["Active", "Expired", "Suspended"], state="readonly")
    status_menu.pack(pady=5)
    status_menu.config(font=("Arial", 12), width=15)  
    buttons_frame = ctk.CTkFrame(admin_win)
    buttons_frame.pack(pady=10)
    pastel_orange = "#FAD4B7"

    ctk.CTkButton( buttons_frame, text="Approve Payment", command=approve_payment, fg_color=pastel_orange, text_color="black").pack(side="left", padx=5, pady=5)
    ctk.CTkButton( buttons_frame, text="Update Status", command=update_status, fg_color=pastel_orange, text_color="black").pack(side="left", padx=5, pady=5)
    ctk.CTkButton( buttons_frame, text="Renew Membership", command=renew_membership,fg_color=pastel_orange, text_color="black").pack(side="left", padx=5, pady=5)
    ctk.CTkButton( buttons_frame, text="Delete User", command=delete_user, fg_color=pastel_orange, text_color="black").pack(side="left", padx=5, pady=5)
    ctk.CTkButton( buttons_frame, text="User Information", command=view_user_info, fg_color=pastel_orange, text_color="black").pack(side="left", padx=5, pady=5)
    ctk.CTkButton( buttons_frame, text="View Deleted Users", command=view_deleted_users, fg_color=pastel_orange, text_color="black").pack(side="left", padx=5, pady=5)

    bottom_buttons_frame = ctk.CTkFrame(admin_win)
    bottom_buttons_frame.pack(pady=10)

    for child in buttons_frame.winfo_children():
        child.configure(height=30, width=110)

    ctk.CTkButton( bottom_buttons_frame, text="Edit User Info", command=edit_user_info, fg_color=pastel_orange, text_color="black").pack(side="left", padx=5, pady=5)
    ctk.CTkButton( bottom_buttons_frame, text="Manage Equipment", command=manage_equipment, fg_color=pastel_orange, text_color="black").pack(side="left", padx=5, pady=5)
    ctk.CTkButton( bottom_buttons_frame, text="Log-out", width=200, command=BacktoMain, fg_color=pastel_orange, text_color="black").pack(side="left", padx=5, pady=5)
    
    load_users()

def adminLogin():#This function gets the admin username and password to etner the admin Dashboard
    admin_username = usern.get()
    admin_password = passw.get()

    if admin_username == "admin" and admin_password == "admin":
        messagebox.showinfo("Success", "Admin login successful!")
        app.withdraw()
        admin_UserLogin()  # Open the admin dashboard
    else:
        messagebox.showerror("Error", "Invalid admin credentials. Please try again.")
        clear_inputs()

#--------------------------------MAIN WINDOW---------------------------------#
app = ctk.CTk()
app.geometry("825x550")
app.resizable(False,False)
app.title("Time4Fitness")

screen_width = app.winfo_screenwidth()
screen_height = app.winfo_screenheight()

x = (screen_width // 2) - (825 // 2)
y = (screen_height // 2) - (550 // 2)
app.geometry(f"825x550+{x}+{y}")

background_image = Image.open("assets/Time4Fitness.png")
Backg = ctk.CTkImage(light_image=background_image, size=(825, 550))
labelbg = ctk.CTkLabel(app, image=Backg, text="")
labelbg.place(relwidth=1, relheight=1)

title_font = ctk.CTkFont(family="Lato", size=35, weight="bold")

frame = ctk.CTkFrame(app, width=400, height=300, fg_color="gray")
frame.place(relx=0.75, rely=0.53, anchor="center")

label1 = ctk.CTkLabel(frame, text="WELCOME\nGYM MEMBERS", font=("Helvetica", 25), text_color="white")
label1.grid(row=0, column=0, padx=10, pady=20)

def clear_inputs(): #This is to clear the input in the username and Password that has inputed.
    usern.delete(0, tk.END)
    passw.delete(0, tk.END)

usern = ctk.CTkEntry(frame, placeholder_text="Username", width=250, corner_radius=10)
usern.grid(row=1, column=0, padx=10, pady=10)

passw = ctk.CTkEntry(frame, placeholder_text="Password", show="*", width=250, corner_radius=10)
passw.grid(row=2, column=0, padx=10, pady=10)

login = ctk.CTkButton(frame, text="Login", width=250, text_color="black" ,fg_color="white", corner_radius=10, command=UserLogin)
login.grid(row=3, column=0, padx=10, pady=7)

adminLogin = ctk.CTkButton(frame, text="Admin Login", width=250, text_color="black", fg_color="white", corner_radius=10, command=adminLogin)
adminLogin.grid(row=4, column=0, padx=10, pady=5)

label2 = ctk.CTkLabel(frame, text="Don't have an account yet? ", text_color="white", font=("Arial", 12))
label2.grid(row=5, column=0, padx=36, pady=(10, 5), sticky="w")

labelreg = ctk.CTkLabel(frame, text="Register", text_color="white", font=("Arial", 12, "underline"))
labelreg.grid(row=5, column=0, padx=(185, 10), pady=(10, 5), sticky="w")
labelreg.bind("<Button-1>", lambda e: regwindow())

app.mainloop()