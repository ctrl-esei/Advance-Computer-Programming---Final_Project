-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Dec 11, 2024 at 03:07 PM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.0.28

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `FitnessDB`
--

-- --------------------------------------------------------

--
-- Table structure for table `Attendance`
--

CREATE TABLE `Attendance` (
  `Attendance_ID` int(11) NOT NULL,
  `User_ID` int(11) NOT NULL,
  `Attendance_Date` date NOT NULL,
  `Check_In_Time` time DEFAULT curtime(),
  `Status` enum('Present','Absent') DEFAULT 'Absent'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `Attendance`
--

INSERT INTO `Attendance` (`Attendance_ID`, `User_ID`, `Attendance_Date`, `Check_In_Time`, `Status`) VALUES
(1, 1, '2024-11-27', '14:52:47', 'Present'),
(2, 4, '2024-11-27', '14:53:23', 'Present'),
(3, 5, '2024-11-27', '14:53:39', 'Present'),
(5, 6, '2024-11-27', '15:18:38', 'Present'),
(6, 2, '2024-11-27', '15:18:48', 'Present'),
(13, 13, '2024-11-27', '16:40:59', 'Present'),
(16, 15, '2024-11-27', '17:32:28', 'Present'),
(20, 16, '2024-11-27', '21:57:30', 'Present'),
(21, 2, '2024-11-29', '01:35:04', 'Present'),
(22, 2, '2024-12-01', '23:38:44', 'Present'),
(25, 21, '2024-12-03', '00:47:50', 'Present'),
(26, 1, '2024-12-05', '19:40:57', 'Present'),
(28, 22, '2024-12-11', '19:55:33', 'Present');

-- --------------------------------------------------------

--
-- Table structure for table `Deleted_Users`
--

CREATE TABLE `Deleted_Users` (
  `DeletedUser_ID` int(11) NOT NULL,
  `User_ID` int(11) NOT NULL,
  `First_Name` varchar(50) DEFAULT NULL,
  `Last_Name` varchar(50) DEFAULT NULL,
  `User_Name` varchar(50) DEFAULT NULL,
  `Pass_word` varchar(255) DEFAULT NULL,
  `Age` int(11) DEFAULT NULL,
  `Email` varchar(100) DEFAULT NULL,
  `Address` varchar(255) DEFAULT NULL,
  `Phone` varchar(20) DEFAULT NULL,
  `Trainer_ID` int(11) DEFAULT NULL,
  `Membership_ID` int(11) DEFAULT NULL,
  `Deletion_Date` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `Deleted_Users`
--

INSERT INTO `Deleted_Users` (`DeletedUser_ID`, `User_ID`, `First_Name`, `Last_Name`, `User_Name`, `Pass_word`, `Age`, `Email`, `Address`, `Phone`, `Trainer_ID`, `Membership_ID`, `Deletion_Date`) VALUES
(1, 20, 'Christaliza', 'Pornea', 'Taliz', 'thunder34', 23, 'Talis.Pornea@gmail.com', 'Tawilisan Taal, Batangas', '09012345678', 2, 1, '2024-11-27 22:31:54'),
(2, 18, 'Angelica', 'De Villa', 'Angel', 'victory99', 21, 'AngelDevilla@gmail.com', 'San Luis Taal, Batangas', '09890123456', 1, 1, '2024-11-27 22:31:58'),
(3, 17, 'Zhandy', 'Hernandez', 'Zansan', 'dragon21', 20, 'Zhandy.Hernandez@gmail.com', 'Sta. Teresita Batangas', '09789012345', 2, 1, '2024-11-27 22:32:00'),
(4, 14, 'Wilma', 'Alvaira', 'Wilms', 'ocean123', 45, 'WilmaAlv@gmail.com', 'Balete San Nicolas, Batangas', '09456789012', 1, 1, '2024-11-27 22:32:10'),
(5, 11, 'Dennise Marie', 'Menor', 'Denn', 'tiger2024', 19, 'Dennisemmenor@gmail.com', 'Oriental Mindoro', '09123456789', 1, 1, '2024-11-27 22:32:21'),
(6, 12, 'Cj', 'Malabanan', 'Sij', 'sunset89', 20, 'sijMalabanan@gmail.com', 'Bauan, Batangas', '09234567890', 2, 1, '2024-11-27 22:32:26'),
(7, 9, 'Anne Margaret', 'Canales', 'Anne', 'Cedi4life', 20, 'annecanales@gmail.com', 'Sta. Teresita Batangas', '09637415209', 2, 1, '2024-11-27 22:32:39'),
(8, 7, 'Mirachael Joy', 'Villavicencio', 'MJ', 'callofduty', 19, 'mjvillavicencio@gmail.com', 'Balisong Taal, Batangas', '09955122521', 2, 1, '2024-11-27 22:32:42'),
(9, 8, 'Paul Angelo', 'Ruego', 'Paul', 'coleilat', 16, 'paulruego@gmail.com', 'Block 2 Lot 11 Trento St. Villagio De Xavier Prima Casa Jubilation Biñan Laguna', '09605129910', 1, 2, '2024-11-27 22:32:51'),
(10, 19, 'Roselene', 'De Castro', 'Roselene', 'rainbow67', 35, 'Roselene.DC@gmail.com', 'Villagio East Biñan Laguna', '09901234567', 2, 3, '2024-11-27 22:33:29'),
(11, 22, 'Jane', 'Doe', 'Jane', '0605', 19, 'jhersslesei@gmail.com', 'Taal, Batangas', '09553365781', 1, 2, '2024-12-02 20:33:40'),
(12, 23, 'Juan', 'Dela Cruz', 'John', 'JohnDC', 19, 'JohnnyDc@gmail.com', 'Gapan, Nueva Ecija', '093684934567', 2, 3, '2024-12-02 20:33:44'),
(13, 10, 'Marie Jerica Shanelle', 'Fermin', 'Shane', 'catlover123', 20, 'shanefermin@gmail.com', 'Sta. Teresita Taal, Batangas', '09678519742', 1, 4, '2024-12-08 19:17:00'),
(14, 3, 'Ashton', 'Villalobos', 'Ash', 'Billiards123', 20, 'ashtonvillalobos@gmail.com', 'Lemery, Batangas', '09692516952', 2, 2, '2024-12-11 19:56:34');

-- --------------------------------------------------------

--
-- Table structure for table `Equipments`
--

CREATE TABLE `Equipments` (
  `Equipment_ID` int(11) NOT NULL,
  `Equipment_Name` varchar(100) NOT NULL,
  `Equipment_Type` varchar(50) DEFAULT NULL,
  `Status` enum('Available','In Maintenance','Out of Order') DEFAULT 'Available'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `Equipments`
--

INSERT INTO `Equipments` (`Equipment_ID`, `Equipment_Name`, `Equipment_Type`, `Status`) VALUES
(1, 'Treadmill', 'Cardio', 'Out of Order'),
(2, 'Dumbbells', 'Strength', 'Available'),
(3, 'Elliptical Trainer', 'Cardio', 'Available'),
(4, 'Barbell', 'Strength', 'Available'),
(5, 'Stationary Bike', 'Cardio', 'In Maintenance'),
(6, 'Bench Press', 'Strength', 'Available'),
(7, 'Rowing Machine', 'Cardio', 'Available'),
(8, 'Kettlebell', 'Strength', 'Available'),
(9, 'Leg Press Machine', 'Strength', 'Available'),
(10, 'Pull-Up Bar', 'Strength', 'Available');

-- --------------------------------------------------------

--
-- Table structure for table `exercise_log`
--

CREATE TABLE `exercise_log` (
  `Exercise_ID` int(11) NOT NULL,
  `User_ID` int(11) DEFAULT NULL,
  `log_date` datetime DEFAULT current_timestamp(),
  `Equipment_ID` int(11) DEFAULT NULL,
  `Equipment_Name` varchar(100) DEFAULT NULL,
  `Sets` int(11) NOT NULL,
  `Reps` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `exercise_log`
--

INSERT INTO `exercise_log` (`Exercise_ID`, `User_ID`, `log_date`, `Equipment_ID`, `Equipment_Name`, `Sets`, `Reps`) VALUES
(1, 1, '2024-11-27 14:52:28', 2, 'Dumbbells', 5, 9),
(2, 1, '2024-11-27 14:52:41', 8, 'Kettlebell', 10, 2),
(3, 4, '2024-11-27 14:53:20', 10, 'Pull-Up Bar', 5, 4),
(4, 5, '2024-11-27 14:53:45', 7, 'Rowing Machine', 10, 1),
(5, 5, '2024-11-27 14:54:00', 9, 'Leg Press Machine', 5, 3),
(8, 6, '2024-11-27 15:18:34', 3, 'Elliptical Trainer', 10, 3),
(9, 2, '2024-11-27 15:18:55', 9, 'Leg Press Machine', 10, 2),
(15, 6, '2024-11-27 15:31:52', 7, 'Rowing Machine', 5, 5),
(18, 13, '2024-11-27 16:41:10', 2, 'Dumbbells', 5, 5),
(19, 13, '2024-11-27 16:41:14', 4, 'Barbell', 3, 5),
(20, 13, '2024-11-27 16:41:21', 8, 'Kettlebell', 10, 4),
(23, 15, '2024-11-27 17:32:06', 4, 'Barbell', 5, 4),
(24, 15, '2024-11-27 17:32:13', 6, 'Bench Press', 5, 5),
(25, 15, '2024-11-27 17:32:19', 8, 'Kettlebell', 3, 5),
(29, 16, '2024-11-27 21:57:20', 3, 'Elliptical Trainer', 4, 5),
(30, 16, '2024-11-27 21:57:27', 6, 'Bench Press', 3, 4),
(31, 2, '2024-11-29 09:11:10', 3, 'Elliptical Trainer', 5, 3),
(32, 2, '2024-12-01 23:38:36', 2, 'Dumbbells', 5, 3),
(35, 21, '2024-12-03 00:47:45', 1, 'Treadmill', 3, 10),
(38, 22, '2024-12-11 19:55:28', 9, 'Leg Press Machine', 10, 3);

-- --------------------------------------------------------

--
-- Table structure for table `Memberships`
--

CREATE TABLE `Memberships` (
  `Membership_ID` int(11) NOT NULL,
  `Membership_Type` varchar(50) NOT NULL DEFAULT 'Standard',
  `Membership_Cost` decimal(10,2) DEFAULT NULL,
  `Membership_Duration` int(11) DEFAULT NULL,
  `Status` enum('Active','Expired') DEFAULT 'Active'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `Memberships`
--

INSERT INTO `Memberships` (`Membership_ID`, `Membership_Type`, `Membership_Cost`, `Membership_Duration`, `Status`) VALUES
(1, 'Daily Pass', 50.00, 1, 'Active'),
(2, 'Basic Package', 1000.00, 30, 'Active'),
(3, 'Standard Package', 2499.00, 90, 'Active'),
(4, 'Premium Package', 4499.00, 180, 'Active');

-- --------------------------------------------------------

--
-- Table structure for table `Payments`
--

CREATE TABLE `Payments` (
  `Payment_ID` int(11) NOT NULL,
  `User_ID` int(11) NOT NULL,
  `Membership_ID` int(11) NOT NULL,
  `Membership_Type` varchar(255) NOT NULL,
  `Payment_Date` date NOT NULL,
  `Amount` decimal(10,2) NOT NULL,
  `Status` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `Payments`
--

INSERT INTO `Payments` (`Payment_ID`, `User_ID`, `Membership_ID`, `Membership_Type`, `Payment_Date`, `Amount`, `Status`) VALUES
(3, 1, 1, 'Daily Pass', '2024-11-27', 50.00, 'Approved'),
(5, 5, 3, 'Standard Package', '2024-11-27', 2499.00, 'Approved'),
(8, 6, 4, 'Premium Package', '2024-11-27', 4499.00, 'Approved'),
(9, 2, 2, 'Basic Package', '2024-11-27', 1000.00, 'Approved'),
(10, 4, 3, 'Standard Package', '2024-11-27', 2499.00, 'Approved'),
(13, 13, 3, 'Standard Package', '2024-11-27', 2499.00, 'Approved'),
(16, 15, 4, 'Premium Package', '2024-11-27', 4499.00, 'Approved'),
(20, 16, 4, 'Premium Package', '2024-11-27', 4499.00, 'Approved'),
(21, 21, 1, 'Daily Pass', '2024-12-08', 50.00, 'Approved'),
(22, 22, 1, 'Daily Pass', '2024-12-11', 50.00, 'Approved'),
(23, 21, 2, 'Basic Package', '2024-12-11', 1000.00, 'Approved');

-- --------------------------------------------------------

--
-- Stand-in structure for view `totalsalesbyyear`
-- (See below for the actual view)
--
CREATE TABLE `totalsalesbyyear` (
`Year` int(4)
,`Total_Sales` decimal(32,2)
);

-- --------------------------------------------------------

--
-- Table structure for table `Trainers`
--

CREATE TABLE `Trainers` (
  `Trainer_ID` int(11) NOT NULL,
  `Trainer_Name` varchar(255) NOT NULL,
  `Trainer_specialization` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `Trainers`
--

INSERT INTO `Trainers` (`Trainer_ID`, `Trainer_Name`, `Trainer_specialization`) VALUES
(1, 'Kier', 'Strength and Conditioning'),
(2, 'Frankin', 'Strength and Conditioning');

-- --------------------------------------------------------

--
-- Table structure for table `Users`
--

CREATE TABLE `Users` (
  `User_ID` int(11) NOT NULL,
  `First_Name` varchar(50) DEFAULT NULL,
  `Last_Name` varchar(50) DEFAULT NULL,
  `User_Name` varchar(50) DEFAULT NULL,
  `Pass_word` varchar(255) DEFAULT NULL,
  `Age` int(11) DEFAULT NULL,
  `Email` varchar(100) DEFAULT NULL,
  `Address` text DEFAULT NULL,
  `Phone` varchar(15) DEFAULT NULL,
  `Trainer_ID` int(11) DEFAULT NULL,
  `Membership_ID` int(11) DEFAULT NULL,
  `Status` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `Users`
--

INSERT INTO `Users` (`User_ID`, `First_Name`, `Last_Name`, `User_Name`, `Pass_word`, `Age`, `Email`, `Address`, `Phone`, `Trainer_ID`, `Membership_ID`, `Status`) VALUES
(1, 'Kier', 'Alvaira', 'Kikey', '0605', 19, 'kieralvaira@gmail.com', 'Balete San Nicolas, Batangas', '09159784813', 2, 1, 'Expired'),
(2, 'Arcklynh', 'Torrano', 'Arck', 'gandahkoh12', 19, 'arcklynh.c.torrano@gmail.com', 'Taal, Batangas', '09671960561', 1, 2, 'Active'),
(4, 'Frankin', 'Dela Torre', 'Frankdeltor', 'RcFrank123', 20, 'frankdeltor@gmail.com', 'Taal, Batangas', '09759237094', 1, 3, 'Active'),
(5, 'Jaspher', 'Malabanan', 'Jas', 'Newbalance', 20, 'jaspherandrei@gmail.com', 'Mahayahay Lemery, Batangas', '09852288768', 2, 3, 'Suspended'),
(6, 'Nadine', 'Lopez', 'Nads', 'chanel', 19, 'nadinelopez@gmail.com', 'Puerto Galera, Mindoro', '09264692968', 1, 4, 'Active'),
(13, 'Gissle', 'Torrano', 'Gissle', 'moonlight17', 46, 'Gisslec.Torrano@gmail.com', 'Taal, Batangas', '09369251225', 2, 3, 'Active'),
(15, 'Daniel', 'Cabanding', 'Danny', 'starlight5', 16, 'DanielCabs@gmail.com', 'Villagio De Xaiver Biñan Laguna', '09567890123', 1, 4, 'Active'),
(16, 'Kielly', 'Cabanding', 'Kielly', 'champion45', 16, 'KiellyCabs@gmail.com', 'Villagio De Xavier Biñan Laguna', '09678901234', 1, 4, 'Active'),
(21, 'Madelin', 'Benamer', 'Mads', 'HevHabi', 19, 'Mads1919@gmail.com', 'Saimsim Sta. Teresita Batangas', '09638273641', 2, 2, 'Active'),
(22, 'John', 'Doe', 'Johnny', 'JohnnyDoe', 19, 'JohnnyDept@gmail.com', 'Batangas City', '09955122521', 1, 1, 'Active');

-- --------------------------------------------------------

--
-- Stand-in structure for view `usersbymembership`
-- (See below for the actual view)
--
CREATE TABLE `usersbymembership` (
`User_ID` int(11)
,`First_Name` varchar(50)
,`Last_Name` varchar(50)
,`Membership_Type` varchar(50)
,`Membership_Cost` decimal(10,2)
,`Status` varchar(20)
);

-- --------------------------------------------------------

--
-- Table structure for table `user_memberships`
--

CREATE TABLE `user_memberships` (
  `User_Membership_ID` int(11) NOT NULL,
  `User_ID` int(11) NOT NULL,
  `Membership_ID` int(11) NOT NULL,
  `Membership_Start_Date` date NOT NULL,
  `Membership_Duration` int(11) NOT NULL,
  `Membership_End_Date` date GENERATED ALWAYS AS (`Membership_Start_Date` + interval `Membership_Duration` day) STORED,
  `Status` varchar(20) DEFAULT 'Active'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `user_memberships`
--

INSERT INTO `user_memberships` (`User_Membership_ID`, `User_ID`, `Membership_ID`, `Membership_Start_Date`, `Membership_Duration`, `Status`) VALUES
(1, 1, 1, '2024-11-27', 1, 'Active'),
(2, 2, 2, '2024-11-27', 30, 'Active'),
(4, 4, 3, '2024-11-27', 90, 'Active'),
(5, 5, 3, '2024-11-27', 90, 'Active'),
(6, 6, 4, '2024-11-27', 180, 'Active'),
(13, 13, 3, '2024-11-27', 90, 'Active'),
(15, 15, 4, '2024-11-27', 180, 'Active'),
(16, 16, 4, '2024-11-27', 180, 'Active'),
(25, 21, 1, '2024-12-03', 1, 'Active'),
(27, 22, 1, '2024-12-11', 1, 'Active');

-- --------------------------------------------------------

--
-- Structure for view `totalsalesbyyear`
--
DROP TABLE IF EXISTS `totalsalesbyyear`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `fitnessdb`.`totalsalesbyyear`  AS SELECT year(`p`.`Payment_Date`) AS `Year`, sum(`m`.`Membership_Cost`) AS `Total_Sales` FROM ((`fitnessdb`.`payments` `p` join `fitnessdb`.`memberships` `m` on(`p`.`Membership_ID` = `m`.`Membership_ID`)) join `fitnessdb`.`users` `u` on(`p`.`User_ID` = `u`.`User_ID`)) GROUP BY year(`p`.`Payment_Date`) ;

-- --------------------------------------------------------

--
-- Structure for view `usersbymembership`
--
DROP TABLE IF EXISTS `usersbymembership`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `fitnessdb`.`usersbymembership`  AS SELECT `u`.`User_ID` AS `User_ID`, `u`.`First_Name` AS `First_Name`, `u`.`Last_Name` AS `Last_Name`, `m`.`Membership_Type` AS `Membership_Type`, `m`.`Membership_Cost` AS `Membership_Cost`, `u`.`Status` AS `Status` FROM (`fitnessdb`.`users` `u` left join `fitnessdb`.`memberships` `m` on(`u`.`Membership_ID` = `m`.`Membership_ID`)) ;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `Attendance`
--
ALTER TABLE `Attendance`
  ADD PRIMARY KEY (`Attendance_ID`),
  ADD KEY `User_ID` (`User_ID`);

--
-- Indexes for table `Deleted_Users`
--
ALTER TABLE `Deleted_Users`
  ADD PRIMARY KEY (`DeletedUser_ID`),
  ADD KEY `Trainer_ID` (`Trainer_ID`),
  ADD KEY `Membership_ID` (`Membership_ID`);

--
-- Indexes for table `Equipments`
--
ALTER TABLE `Equipments`
  ADD PRIMARY KEY (`Equipment_ID`),
  ADD UNIQUE KEY `unique_Equipment_Name` (`Equipment_Name`);

--
-- Indexes for table `exercise_log`
--
ALTER TABLE `exercise_log`
  ADD PRIMARY KEY (`Exercise_ID`),
  ADD KEY `fk_Equipment_ID` (`Equipment_ID`),
  ADD KEY `fk_Equipment_Name` (`Equipment_Name`),
  ADD KEY `exercise_log_ibfk_1` (`User_ID`);

--
-- Indexes for table `Memberships`
--
ALTER TABLE `Memberships`
  ADD PRIMARY KEY (`Membership_ID`),
  ADD UNIQUE KEY `Membership_Type` (`Membership_Type`);

--
-- Indexes for table `Payments`
--
ALTER TABLE `Payments`
  ADD PRIMARY KEY (`Payment_ID`),
  ADD KEY `User_ID` (`User_ID`),
  ADD KEY `fk_membership_id` (`Membership_ID`),
  ADD KEY `fk_membership_type` (`Membership_Type`);

--
-- Indexes for table `Trainers`
--
ALTER TABLE `Trainers`
  ADD PRIMARY KEY (`Trainer_ID`);

--
-- Indexes for table `Users`
--
ALTER TABLE `Users`
  ADD PRIMARY KEY (`User_ID`),
  ADD UNIQUE KEY `User_Name` (`User_Name`),
  ADD KEY `Trainer_ID` (`Trainer_ID`),
  ADD KEY `Membership_ID` (`Membership_ID`);

--
-- Indexes for table `user_memberships`
--
ALTER TABLE `user_memberships`
  ADD PRIMARY KEY (`User_Membership_ID`),
  ADD KEY `Membership_ID` (`Membership_ID`),
  ADD KEY `user_memberships_ibfk_1` (`User_ID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `Attendance`
--
ALTER TABLE `Attendance`
  MODIFY `Attendance_ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=29;

--
-- AUTO_INCREMENT for table `Deleted_Users`
--
ALTER TABLE `Deleted_Users`
  MODIFY `DeletedUser_ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `Equipments`
--
ALTER TABLE `Equipments`
  MODIFY `Equipment_ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `exercise_log`
--
ALTER TABLE `exercise_log`
  MODIFY `Exercise_ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=39;

--
-- AUTO_INCREMENT for table `Memberships`
--
ALTER TABLE `Memberships`
  MODIFY `Membership_ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `Payments`
--
ALTER TABLE `Payments`
  MODIFY `Payment_ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;

--
-- AUTO_INCREMENT for table `Trainers`
--
ALTER TABLE `Trainers`
  MODIFY `Trainer_ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `Users`
--
ALTER TABLE `Users`
  MODIFY `User_ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;

--
-- AUTO_INCREMENT for table `user_memberships`
--
ALTER TABLE `user_memberships`
  MODIFY `User_Membership_ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=28;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `Attendance`
--
ALTER TABLE `Attendance`
  ADD CONSTRAINT `attendance_ibfk_1` FOREIGN KEY (`User_ID`) REFERENCES `Users` (`User_ID`) ON DELETE CASCADE;

--
-- Constraints for table `Deleted_Users`
--
ALTER TABLE `Deleted_Users`
  ADD CONSTRAINT `deleted_users_ibfk_1` FOREIGN KEY (`Trainer_ID`) REFERENCES `Trainers` (`Trainer_ID`),
  ADD CONSTRAINT `deleted_users_ibfk_2` FOREIGN KEY (`Membership_ID`) REFERENCES `Memberships` (`Membership_ID`);

--
-- Constraints for table `exercise_log`
--
ALTER TABLE `exercise_log`
  ADD CONSTRAINT `FK_Equipment` FOREIGN KEY (`Equipment_ID`) REFERENCES `Equipments` (`Equipment_ID`),
  ADD CONSTRAINT `exercise_log_ibfk_1` FOREIGN KEY (`User_ID`) REFERENCES `Users` (`User_ID`) ON DELETE CASCADE,
  ADD CONSTRAINT `fk_Equipment_ID` FOREIGN KEY (`Equipment_ID`) REFERENCES `Equipments` (`Equipment_ID`) ON DELETE SET NULL,
  ADD CONSTRAINT `fk_Equipment_Name` FOREIGN KEY (`Equipment_Name`) REFERENCES `Equipments` (`Equipment_Name`) ON DELETE SET NULL;

--
-- Constraints for table `Payments`
--
ALTER TABLE `Payments`
  ADD CONSTRAINT `fk_membership_id` FOREIGN KEY (`Membership_ID`) REFERENCES `Memberships` (`Membership_ID`),
  ADD CONSTRAINT `fk_membership_type` FOREIGN KEY (`Membership_Type`) REFERENCES `Memberships` (`Membership_Type`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `payments_ibfk_1` FOREIGN KEY (`User_ID`) REFERENCES `Users` (`User_ID`);

--
-- Constraints for table `Users`
--
ALTER TABLE `Users`
  ADD CONSTRAINT `Membership_ID` FOREIGN KEY (`Membership_ID`) REFERENCES `Memberships` (`Membership_ID`) ON DELETE SET NULL,
  ADD CONSTRAINT `Trainer_ID` FOREIGN KEY (`Trainer_ID`) REFERENCES `Trainers` (`Trainer_ID`) ON DELETE SET NULL;

--
-- Constraints for table `user_memberships`
--
ALTER TABLE `user_memberships`
  ADD CONSTRAINT `user_memberships_ibfk_1` FOREIGN KEY (`User_ID`) REFERENCES `Users` (`User_ID`) ON DELETE CASCADE,
  ADD CONSTRAINT `user_memberships_ibfk_2` FOREIGN KEY (`Membership_ID`) REFERENCES `Memberships` (`Membership_ID`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
